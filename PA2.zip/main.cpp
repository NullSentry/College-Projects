#include <iostream>
#include <string>
#include <sys/wait.h>
#include <filesystem>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <vector>
#include <algorithm>
#include <cstring>
#include <filesystem>
#include <limits.h>
using std::string;
using std::cout;
using std::endl;
using std::cin;
using std::vector;
using std::copy;
using std::find;

void trim(string& str){
    while (str.front() == ' ')
        str.erase(0,1);
    while (str.back() == ' ')
        str.pop_back();
}

void clean(vector<string>& parts){
    vector<string> clnparts;
    for(auto i: parts){
        if (i.size() > 0)
            clnparts.push_back(i);
    }
    parts = clnparts;
    //parts.push_back("");
}

vector<string> split(string str, char del=' '){
    vector<string> words;
    bool dquote = false;
    bool squote = false;
      string csums = "";
      for(int i=0; i<str.size(); i++){
         if((str[i] != del) || (dquote || squote)){
            if (dquote || squote){
                if (str[i]=='"' && !squote)
                    dquote=false;
                if (str[i]=='\'' && !dquote)
                    squote=false;
            }else{
                if (str[i]=='"' && !squote)
                    dquote=true;
                if (str[i]=='\'' && !dquote)
                    squote=true;
            }
            csums += str[i];
        }
          else{
            words.push_back(csums);
            csums = "";
        }
    }
    words.push_back(csums);
    //for (auto i : words){
    //    cout << i << endl;
    //}
    return words;
}

string arrow_space(string inputline){
    bool dquote = false;
    bool squote = false;
    for (int i = 1; i < inputline.size()-1; i ++){
        if (dquote || squote){
            if (inputline[i] == '>'){
                if (inputline[i-1] != ' '){
                    inputline.insert(i, " ");
                    i++;
                }
                if (inputline[i+1] != ' '){
                    inputline.insert(i+1, " ");
                }
            }
            if (inputline[i] == '<'){
               if (inputline[i-1] != ' '){
                    inputline.insert(i, " ");
                    i++;
                }
                if (inputline[i+1] != ' '){
                    inputline.insert(i+1, " ");
                } 
            }
            if (inputline[i]=='"' && squote)
                dquote=false;
            if (inputline[i]=='\'' && dquote)
                squote=false;
        }else{
            if (inputline[i]=='"' && !squote)
                    dquote=true;
            if (inputline[i]=='\'' && !dquote)
                squote=true;
        }
    }
    return inputline;
}

void quoteclean(char*& cstr, int len){
    if ((cstr[0] == '\"') && (cstr[len] == '\"') ||
        (cstr[0] == '\'') && (cstr[len] == '\'')){
        cstr = &cstr[1]; // Moves begining up 1 value
        cstr[len-1] = '\0'; // Sets a end char to last value, decrimenting char* by one
    }
}

char** vector_to_char_array(vector<string>& parts){
    char** cformat = new char* [parts.size()];
    for (int i = 0; i < parts.size(); i++){
        cformat[i] = &(parts[i])[0]+'\0'; // Actual black magic
        quoteclean(cformat[i], parts[i].size()-1);
    }
    cformat[parts.size()-1] = NULL;
    return cformat;
}

string* checkStd(vector<string>& parts){
    vector<string> clnparts;
    string* check = new string[2];
    check[0], check[1] = "";
    for (int i = 0; i < parts.size(); i++){
        if ((parts[i].compare("<")) == 0){
            check[0] = parts[i+1];
            i++;
        }else if ((parts[i].compare(">")) == 0){
            check[1] = parts[i+1];
            i++;
        }else {clnparts.push_back(parts[i]);}
    }
    parts = clnparts;
    parts.push_back("");
    return check;
}

int execute(char**& args, string* inout){
    // preparing the input command for execution
    if (inout[0].size()){
        int fd = open (inout[0].c_str(), O_CREAT|O_RDONLY, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
        dup2 (fd, 0); // overwriting stdin with the new file
    }
    if (inout[1].size()){
        int fd = open (inout[1].c_str(), O_CREAT|O_WRONLY|O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
        dup2 (fd, 1); // overwriting stdout with the new file
    }
    execvp (args[0], args);
    return 0;
}

void navigate(char**& args, vector<string>& parts, char*& cwd, vector<char*>& history, vector<string>::iterator it){
    char* arg;
    if (parts.size() > 2)
        arg = args[(it-parts.begin()) + 1];
    else
        arg = new char[1];

    if (strcmp(arg, "-")){
        cwd = get_current_dir_name();
        chdir(arg);
        if (strcmp(cwd, get_current_dir_name())){
            history.push_back(cwd);
        }
    }else{
        chdir(history.back()); 
        history.pop_back();
    }
}

int main (){
    char* home = getenv("HOME");
    char* cwd;
    char hostname[HOST_NAME_MAX + 1];
    string username =  getenv("USER");
    gethostname(hostname, HOST_NAME_MAX + 1);
    vector<char*> history = {get_current_dir_name()};
    vector<int> bgs;
    int in_def = dup(0);
    int out_def = dup(1);
    while (true){
        dup2(in_def, 0);
        dup2(out_def, 1);
        for (int i=0; i<bgs.size(); i++){
            if (waitpid(bgs[i], 0, WNOHANG) == bgs[i]){
                bgs.erase(bgs.begin()+i);i--;
            }
        }
        cout << "\033[1;36m" << username << "@" << hostname <<"\033[0m:\033[1;35m" << get_current_dir_name() << "\033[0m$ ";
        string inputline;
        getline (cin, inputline); //get a line from standard input
        trim(inputline);
        inputline = arrow_space(inputline);
        if (inputline == string("exit")){
            cout << "Bye!! End of shell" << endl;
            break;
        }
        bool bg = false;
        if (inputline.back() == '&'){
            //cout << "Bg process found" << endl;
            bg = true;
            inputline.pop_back();
            if (inputline.back() == ' ')
                inputline.pop_back();
            inputline+='\0';
        }
        vector<string> parts = split(inputline, '|');
        if (parts.size() == 1){
            parts = split(inputline);
            clean(parts);
            string* inout = checkStd(parts);
            /*for (auto i: parts){
                cout << i << endl;
            }*/
            char** args = vector_to_char_array(parts);
            vector<string>::iterator it = 
            find(parts.begin(), parts.end(), "cd");
            if (it != parts.end()){
                navigate(args, parts, cwd, history, it);
            }else{
                int pid = fork ();
                // bool bg = false;
                if (!pid){ //child process
                    if (!execute(args, inout))
                        break;
                }else{
                    if(!bg)
                        waitpid (pid, 0, 0); //parent waits for child process
                    else{
                        bgs.push_back(pid);
                    }
                }
            }
            // Invalid argument, ignore.
        }else{
            //cout << "test" << endl;
            clean(parts);
            for (int i = 0; i < parts.size(); i++){
                trim(parts[i]);
                vector<string> pipeparts = split(parts[i]);
                clean(pipeparts);
                string* inout = checkStd(pipeparts);
                char** args = vector_to_char_array(pipeparts);
                int fd[2];
                pipe(fd);
                int cid = fork();
                if(!cid){
                    if (i < parts.size()-1)
                        dup2(fd[1], 1);
                    close(fd[0]);
                    execute(args, inout);
                }else{
                    if (!bg){
                        waitpid(cid, 0, 0);
                    }else{
                        bgs.push_back(cid);
                    }
                    dup2(fd[0],0);
                    close(fd[1]);
                } 
            }
            // PIPE
        }
    }
}
