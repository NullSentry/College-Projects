All further questions on functionality/design can be addressed in the pdf.
Part1:

The design of the CPU has 8 registers.
I simply completed the remaining registers.

Part2:

Using the provided LoadReg circut, I plugged LoadReg into a Dmux8Way in order to produce
the loads of each register. I matched the ouputs to the loads using the provided diagram.
Since N[8:6] determines the load address, I simply made that my DMux selector.

Part3:

Since N[11] determines if the value is an ALU operation or a Memory/Jump value, 
I simply had a AluOut and fromM plugged into a Mux16, with N[11] as the selector.

Part 4:

I put all of the register outputs into a two Mux8Way16s in order select X and Y.
Since N[3:5] determines Rx, I used that as the select for the first Mux.
Since N[2:0] determines Ry, I used that as the select for the second Mux.

Then, I connected the X and Y outputs into the ALU, using N[10:9] as the selector.
According to the instructions provided in both the PDF and ALU file, 
N[10] determines if the ALU computes Arithmetic or Logic and
N[9] determines if the operation is Add/And or Sub/Or.

Part 5:
Since N[6:8] is used to determine what register address information is written to,
I simply had all the registers placed into a Mux8Way16, with N[6:8] as the selector.

Part6/7:
Since AddressM is only true if N[10] is zero (Not a jump) and if N[11] is true (Memory/Jmp),
I put N[10] into a not-gate, and put that result, along with N[11] into an and-gate.
I called the result of this circut "Mem".
I then plugged the previously mentioned circut into the load of a register.
Since N[5:0] is the data memory address, I put that into the input of the register, 
which gets loaded if the load is true.

If "Mem" was true, and N[9] is true (since N[9] determines MREAD/MWrite), 
WriteM is true. I used an and-gate to acomplish the logic.

Part8:
Since we needed to check if RyOut is not zero, I simply put RyOut into an Or16Way.
If even one value is true, then it is not equal to zero. 
Since we wish to check if RyOut is NOT zero, the result of the or-gate is negated with a not-gate.
Sicne N[10] determines Mem/Jmp and N[11] deterines Mem/Jmp vs Operations, I put the two in an
and-gate. Since Both N[10] and N[11] must be true in order to jump.
I put the negated or8 and the previously mentioned and-gate into another and gate, which
determines if there is a jump, as OPCODE must be jump, and the jump operation itself must also 
be true.

Part9:
Lastly, I put the PCInput into the PC.
The previous jump calulation is set as the load, and the inc value is set to true, as the PC
always should increment to the next line.
Lastly, the output goes to PCOut.

