The following code simply uses well-known formulas for triangular properties and applies them.
The triangle check formula (R4) uses the triangle inequality theorme.
If one side (R1, R2, or R3) is greater than the sum of all sides, then the object is not a triangle.
Also note: All sides must be greater than zero, as a side's magnitude cannot be negtive &
if the magnitude is zero, it is either a point or line, which is not a triangle.
Basically:
if ((R1 + R2 > R3 & R1 + R3 > R2 & R3 + R2 > R1) & (R1>0 & R2>0 & R3>0)){
 //Triangle
}else{
 //Not triangle
 //Set everything to false and end program
}

To check the type of triangle, R5 is set by default to -1, then the following is applied to R5:
if (R1 = R2 | R1 = R3){ //Check if R1 equals a side, add 1
 R5++
}
if (R2 = R3){ //Check R2 equals a side, add 1
 R5++
}
If all three sides are equal, every single if statement will return true. 
Otherwise if only two sides is equal, only one will return true.
Otherwise, none of the above will return true.

To check if the triangle is a right triangle, I first find the minimum, median, and maximum side.
mini1 = Min(R1, R2, R2)
mini2 = Median(R1, R2, R2)
maxi = Max(R1, R2, R2)
Then you apply the pythagorean theorem. 
If (mini^2 + mini2^2 = maxi^2){
  //right triangle
  //Also set hypotenuse to maxi
}else{
  //not right triangle
}

To calculate the perimiter, you simply add up all of the sides.
R8 = R1+R2+R3


