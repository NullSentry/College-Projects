#include "common.h"
#include "FIFOreqchannel.h"
#include <sys/wait.h>
#include <cstring>
#include <string>
using namespace std;

int main(int argc, char *argv[]){
	struct timeval start, end;
	int opt;
	int p = 1;
	double t = -1;
	int e = 1;
	string filename = "";
	int buffCap = MAX_MESSAGE;
	string buffCapStr = "";
	bool isNewChan = false;
	// take all the arguments first because some of these may go to the server
	while ((opt = getopt(argc, argv, "p:t:e:f:m:c")) != -1) {
		switch (opt) {
			case 'f':
				filename = optarg;
				break;
			case 'p':
				p = atoi(optarg);
				break;
			case 't':
				t = atof(optarg);
				break;
			case 'e':
				e = atoi(optarg);
				break;
			case 'm':
				buffCapStr = optarg;
				buffCap = atoi(optarg);
				break;
			case 'c':
				isNewChan = true;
				break;
		}
	}

	int pid = fork ();
	if (pid < 0){
		EXITONERROR ("Could not create a child process for running the server");
	}
	if (!pid){ // The server runs in the child process
		if (buffCapStr.size()){
			char* args[] = {"./server", "-m", (char*)buffCapStr.c_str(), nullptr};
			if (execvp(args[0], args) < 0){
				EXITONERROR ("Could not launch the server");
			}
		}else{
			char* args[] = {"./server", nullptr};
			if (execvp(args[0], args) < 0){
				 ("Could not launch the server");
			}
		}
	}
	FIFORequestChannel chan ("control", FIFORequestChannel::CLIENT_SIDE);
	if (isNewChan){
		Request nc(NEWCHAN_REQ_TYPE);
		chan.cwrite(&nc, sizeof(nc));
		char chanName [1024];
		chan.cread(chanName, sizeof(chanName));
		FIFORequestChannel newChan (chanName, FIFORequestChannel::CLIENT_SIDE);
		gettimeofday(&start, NULL);
		for (int i=0; i < 1000; i++){ // Testing newChannel to see if it works
			DataRequest d (p, i*.004, e);
			newChan.cwrite (&d, sizeof (DataRequest)); // question
			double reply;
			newChan.cread (&reply, sizeof(double)); //answer
			if (!isValidResponse(&reply)){
				break;
			}else if (!filename.size()){
				cout << "For person " << p <<", at time " << i*.004 << ", the value of ecg "<< e <<" is " << reply << endl;
			} //If there is an output, it works
		}
		gettimeofday(&end, NULL);
		printf("(Bulk Data Points Channel 2) Time elapsed: %ldms\n",
			((end.tv_sec * 1000000 + end.tv_usec) -
			(start.tv_sec * 1000000 + start.tv_usec)));
		Request q (QUIT_REQ_TYPE);
    	newChan.cwrite (&q, sizeof (Request));
	}
	if (t < 0 && !filename.size()){
		gettimeofday(&start, NULL);
		for (int i=0; i < 1000; i++){
			DataRequest d (p, i*.004, e);
			chan.cwrite (&d, sizeof (DataRequest)); // question
			double reply;
			chan.cread (&reply, sizeof(double)); //answer
			if (!isValidResponse(&reply)){
				break;
			}else{
				cout << "For person " << p <<", at time " << i*.004 << ", the value of ecg "<< e <<" is " << reply << endl;
			}
		}
		gettimeofday(&end, NULL);
		printf("(Bulk Data Points) Time elapsed: %ldms\n",
			((end.tv_sec * 1000000 + end.tv_usec) -
			(start.tv_sec * 1000000 + start.tv_usec)));
	}else if (!filename.size()){
		gettimeofday(&start, NULL);
		DataRequest d (p, t, e);
		chan.cwrite (&d, sizeof (DataRequest)); // question
		double reply;
		chan.cread (&reply, sizeof(double)); //answer
		if (isValidResponse(&reply)){
			cout << "For person " << p <<", at time " << t << ", the value of ecg "<< e <<" is " << reply << endl;
		}
		gettimeofday(&end, NULL);
		printf("(Individual Datapoint) Time elapsed: %ldms\n",
			((end.tv_sec * 1000000 + end.tv_usec) -
			(start.tv_sec * 1000000 + start.tv_usec)));
	}
	
	/* this section shows how to get the length of a file
	you have to obtain the entire file over multiple requests 
	(i.e., due to buffer space limitation) and assemble it
	such that it is identical to the original*/

	if (filename.size()){
		gettimeofday(&start, NULL);
		FileRequest fm (0,0);
		int len = sizeof (FileRequest) + filename.size()+1;
		char buf2 [len];
		memcpy (buf2, &fm, sizeof (FileRequest));
		strcpy (buf2 + sizeof (FileRequest), filename.c_str());
		chan.cwrite (buf2, len);  
		int64 filelen;
		chan.cread (&filelen, sizeof(int64));
		if (!isValidResponse(&filelen)){
			exit(0);
		}else{
			cout << "File length is: " << filelen << " bytes" << endl;
		}
		int64 rem = filelen;
		FileRequest* f = (FileRequest*) buf2;
		ofstream of ("./received/"+filename);
		char recvbuf [buffCap];
		while (rem > 0){
			f->length = min(rem, (int64)buffCap);
			chan.cwrite(buf2, len);
			if (f->length > MAX_MESSAGE)
				for(int i = 0; i <= (int)(f->length/MAX_MESSAGE); i++)
					of.write(recvbuf, chan.cread(recvbuf, MAX_MESSAGE));
			else
				of.write(recvbuf, chan.cread(recvbuf, f->length));
			rem -= abs(f->length);
			f->offset += f->length;
		}
		of.close();
		gettimeofday(&end, NULL);
		printf("(File W/R) Time elapsed: %ldms\n",
			((end.tv_sec * 1000000 + end.tv_usec) -
			(start.tv_sec * 1000000 + start.tv_usec)));
	}
	// closing the channel    
    Request q (QUIT_REQ_TYPE);
    chan.cwrite (&q, sizeof (Request));
	// client waiting for the server process, which is the child, to terminate
	wait(0);
	cout << "Client process exited" << endl;
}
