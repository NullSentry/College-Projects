# CSCE 312 - 501: Project X //Modify for submission

This readme describes the implementation of the game "Disk Shoot" programmed using nand2tetris's jack
programming language. This game was created by Zachary Lewis.


### Prerequisites

Please use the Jack Compiler, VM Emulator, and other resources provided by nand2tetris in order to run this game. 
See installation instructions here:
(http://nand2tetris.org/).


## Running

The compiled code is already provided in this file. Please follow the bellow instructions to use the VM emulator.

1. Run the nand2tetris emulator (VMEmulator.bat/VMEmulator.sh depending on your OS)
2. Click the folder icon in the top left corner of the opened program.
3. Navigate to the directory the VM files are saved in.
4. Click the folder that the VM's are located in. Click "Load Program".
Note: Do not attempt to open using the VM files inside, click on the folder that the VM files are stored in.
5. Click view->animate->no program animation (this is to speed up the game)
6. Set the game to either moderate speed or fast using the speed option next to the red flag.
7. Click on the blue double arrow to start the code.
8. Lastly, click on the screen and use your keyboard to control the game.


## Class Structure

1. Main Function
• The main function’s primary function is simply to create the game, run the game, and deallocate the game when it is finished.

2. Game Object (Semi Game)
• The game object is the bread and butter of this project. Its main purpose is to micromanage the objects within the game. 
For example, the game object oversees managing when a hitbox spawn and despawn. 
It also controls how many of said hitboxes can spawn at once.
• Second, the game object is also responsible for determining which values get sent to which function, 
such as sending a specific hitbox object from the hitbox array into the crosshair object’s check shot function, 
which is used to determine if said hitbox got hit by the shot or not.
• Third, this function obtains the user’s inputs and gives those instructions to objects, 
which allow the objects to behave in a certain manner as a result. 
An example of this would be when the user uses the arrow keys or WASD to control the crosshair.
• Fourth, this object draws the background/titlescreen/endscreen graphics. 
These are graphics that do not really need a specific object to micromanage them, 
so they are handled by the game object itself.
• Lastly, the game object manages how long the game lasts, the rules of the game, and the structure of the game itself.

3. Class Objects (Hitbox, Semi, Score, Ect.)
• These are the basic objects that oversee specific tasks.
• The hitbox object primarily oversees managing where the disk is. 
This class also saves the size, x position (& starting x position), y position, speed, and the disk object. 
This object primarily determines where and how big the disk object will be on the screen. 
This object also can return its x position, its y position, its size, its speed, and its trajectory. 
All of these are used to help the game object micromanage the class. 
The x position and y position functions are also used by the crosshair to determine of a disk was successfully shot, 
with the help of the game object.
• The semi (crosshair) object oversees displaying the user’s “character” and moving according to the user’s inputs, 
as provided by the game class. The semi object also determines if a shot hits or misses, 
outputting its accuracy with every hitbox given to it by the object class.
• The score object calculates the users score. This is a continuously incrementing value, 
which is calculated by getting the number of shots in a row and the accuracy of the shot by the crosshair from the game class.
• The time class is class that stores a simple and continuously incrementing integer. 
Every time the game moves, the counter increases the “subtime” counter by one. 
Once the subtime’s value approximately equals the span of a second, 
the subtime counter resets and the time integer increases by one. 
This allows the game class to keep track of how long the game has lasted, 
which the game class then uses to increase the difficulty.
• While a lot of these classes are visible to the player, the hitbox and time class are invisible to the player, 
and instead work in the background to improve gameplay.

4. Functionalities (Math Special, Random)
• These are mathematical operations that are used in all classes except for the main class.
• These operations can be used by any class and are often used to help calculate certain variables.
• The random class uses a seed provided by the game class. 
This seed is then used in the “between” function to determine a pseudo-random integer number between a and b.
• The math special class has three functions, each of which can be used by any object class.
• The first operation is the mod function (which is different from the mod helper function in the random class, 
as it is faster but sufferers from an earlier integer overflow error). This function finds the remainder of a/b.
• The second operation is the exponential function. This function calculates x^y.
• The last operation is the logarithmic function. This function calculates logbaseB(x).

5. Sub-Class Object (Disk)
• The last type of class is the subclass object. 
This is an object that is completely dependent on its parent object to function. 
The hitbox is told to move to point (x,y,z) by the game object. 
The hitbox object then sends that information over to the disk object, 
which then maps out the disk graphic inside of the hitbox onto the screen 
according to the information provided by the hitbox class.
• While this could technically be integrated into the hitbox class, 
it was easier to simply make it its own class, as having the hitbox and disk graphic separate was convenient for debugging.


## Graphical Representation of Structure

(Bar = Creates/Destroys, Arrow = Sends information from tail to head)

                         [ Main ]
                             |
                       [ SemiGame ]
                       |↕        ↕|
[ Hitbox, Semi, Score, Ect. ]↔[ Math Special, Random ]
              |↓
           [ Disk ]


## Built With

This project was programmed in Notepad++ using the Jack programming language.


## Authors

Zachary Lewis


## Acknowledgments

The Random.jack file used in this game is a code provided by Taylor Wacker and Connor McKay.
Link: https://gist.github.com/greneholt/2212294
