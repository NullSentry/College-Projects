from queue import PriorityQueue
from gen_clauses_Sammy import *

def main(): ## Grabs KB and saves it to file. Also runs CNF conversion and saves that to a file too
    x = [1,2,3]
    c = ["Y","W","B"]
    facts = [(1,"O1Y"), (2,"L1W"), (3,"O2W"), (4,"L2Y"), (5,"O3Y"), (6,"L3B")]
    q = PriorityQueue()
    q2 = PriorityQueue()
    v1 = 0
    v2 = 9
    v3 = 18
    v4 = 27
    for o in x:
        for i, j in zip(x, c): ## Need to save to file
            clsa = "C"+(str)(o) + (str)(j) + "->("
            clsb = "C"+(str)(o) + (str)(j) + "->("
            clsc = "L"+(str)(o) + (str)(j) + "->("
            clsd = ""
            if (j != "B"):
                clsd = "O"+(str)(o) + (str)(j) + "->("
            for k, l in zip(x, c):
                if (k == o):
                    clsc += "-C"+(str)(o) + j + "^"
                    if (j != "B"):
                        clsd += "C"+(str)(k) + j + "v" + "C"+(str)(k) + "B" + "^"
                if (j != l):
                    clsa += "-C"+(str)(o) + l + "^"
                if (k != o):
                    clsb += "-C"+(str)(k) + j + "^"
            clsa = clsa[:-1]
            clsa += ")"
            v1+=1
            q.put((v1, clsa))
            clsb = clsb[:-1]
            clsb += ")"
            v2+=1
            q.put((v2, clsb))
            clsc = clsc[:-1]
            clsc += ")"
            v3+=1
            q.put((v3, clsc))
            if (j != "B"):
                clsd = clsd[:-1]
                clsd += ")"
                v4+=1
                q.put((v4, clsd))
            #print(str(v1-1) + ": " + clsa, " ", str(v2-1) + ": " , clsb, " ",str(v3-1) + ": " + clsc, " ",str(v4-1) + ": " +  clsd) ## Need to save to file
            clsa = clean(inv_distParse(distribute(distParse(implication(clsa)))))[1:-1]
            q2.put((v1, andSplit(clsa)))
            clsb = clean(inv_distParse(distribute(distParse(implication(clsb)))))[1:-1]
            q2.put((v2, andSplit(clsb)))
            clsc = clean(inv_distParse(distParse(implication(clsc))))[1:-1]
            q2.put((v3, [clsc]))
            if (j != "B"):
                clsd = clean(inv_distParse(distParse(implication(clsd))))[1:-1]
                q2.put((v4-1, [clsd]))
    cnt = 0
    f = open("Sammy.KB.txt", "w")
    while not q.empty():
        cnt+=1
        next_item = q.get()
        f.write(str(cnt)+": "+next_item[1]+"\n")
    for i in facts:
        f.write(str(cnt+i[0])+": "+i[1]+"\n")
    f.close()
    f = open("Sammy.KB.txt", "r")
    print(f.read()) 
    print("--------")
    cnt = 0
    f = open("Sammy.CNF.txt", "w")
    while not q2.empty():
        next_item = q2.get()
        for i in next_item[1]:
            cnt+=1
            f.write(str(cnt)+": "+i+"\n")
    for i in facts:
        f.write(str(cnt+i[0])+": "+i[1]+"\n")
    f.write(str(cnt+7)+": "+"-C2W"+"\n")
    f.close()
    f = open("Sammy.CNF.txt", "r")
    print(f.read()) 


if __name__=="__main__":
    main()