from queue import PriorityQueue

def andSplit(a):
    str1 = ""
    str2 = ""
    flag = False
    for i in a:
        if (i == "^"):
            flag=True
        elif (not flag):
            str1+=i
        else:
            str2+=i
    return [str1,str2]


def clean(a):
    b = a.replace(" ","")
    b = a.replace("--","")
    return b

def implication(a):
    a = clean(a)
    if (len(a) > 0):
        a = "-"+a
        a = a.replace("->", "v")
    return a

def distParse(a, key="v"):
    a = clean(a)
    if (not "v" in a) and (not "^" in a):
        return a
    dist = []
    curr = ""
    net = 0
    for i in a:
        if ((i != key)):
            if (i == "("):
                net+=1
            if (i == ")"):
                net-=1
            curr+=i
        elif (net == 0):
            dist.append(curr)
            curr = ""
        else:
            curr += key
    dist.append(curr)
    if (key == "v"):
        dist.insert(0,"v")
    else:
        dist.insert(0,"^")
    for i in dist[1:]:
        for j in range(0, len(i)):
            if (i[0] == "(" and (i[-1] == ")")):  
                dist=list(map(lambda x: x.replace(i, i[1:]),dist))
                i = i[1:]
                dist=list(map(lambda x: x.replace(i, i[:-1]),dist))
                i = i[:-1]

    for i in range(1, len(dist)):
        if (key == "v"):
            dist[i] =  distParse(dist[i],"^")
        if (key == "^"):
            dist[i] =  distParse(dist[i],"v")

    if (len(dist) == 2):
        return dist[1]
    return dist

def inv_distParse(a):
    if (isinstance(a, str)):
        return a
    key = a[0]
    curr = "("
    for i in a[1:]:
        curr+= str(inv_distParse(i))+key
    curr = curr[:-1]+")"
    return curr

def distribute(a):
    q = PriorityQueue()
    b = a[:]
    if (len(a) > 0):
        key1 = b[2][0]
        key2 = b[0]
        temp1 = b[1][:]
        if (isinstance(temp1, str)):
            temp1 = [temp1]
        temp2 = b[2][:]
        if (isinstance(temp2, str)):
            temp2 = [temp2][:]
        while (len(b) < len(b[2])):
            b.append([])
        for i in range (1, len(b[2])):
            temp = temp1[:]
            temp.append(temp2[i][:])
            b[i] = temp[:]
            if (b[i][0] != "v" and b[i][0] != "^"):
                b[i].insert(0,key2)
            else:
                b[i][0] = key2
        b[0] = key1
    return b