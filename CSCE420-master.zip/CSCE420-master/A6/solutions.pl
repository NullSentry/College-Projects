/*Simpsons Family Code Start*/
brother(X,Y) :- male(Y),parent(Y,Z),parent(X,Z), X\=Y.
sister(X,Y) :- female(Y),parent(Y,Z),parent(X,Z), X\=Y.
sibling(X,Y) :- brother(X,Y) ; sister(X,Y).
uncle(X,Y) :- male(Y),brother(Y,Z), parent(X,Z).
aunt(X,Y) :- female(Y),sister(Y,Z), parent(X,Z).
pibling(X,Y) :- uncle(X,Y) ; aunt(X,Y).
grandfather(X,Y) :- male(Y),parent(X,Z), parent(Z,Y).
grandmother(X,Y) :- female(Y),parent(X,Z), parent(Z,Y).
grandson(X,Y) :- male(Y),parent(Y,Z), parent(Z,X).
granddaughter(X,Y) :- female(Y),parent(Y,Z), parent(Z,X).
grandparent(X,Y) :- grandfather(X,Y) ; grandmother(X,Y).
ancestor(X,Y) :- parent(X,Y) ; grandparent(X,Y).
unrelated(X,Y) :- \+ ancestor(X,Y), \+ pibling(X,Y), \+ sibling(X,Y).

parent(bart,homer).
parent(bart,marge).
parent(lisa,homer).
parent(lisa,marge).
parent(maggie,homer).
parent(maggie,marge).
parent(homer,abraham).
parent(herb,abraham).
parent(tod,ned).
parent(rod,ned).
parent(marge,jackie).
parent(patty,jackie).
parent(selma,jackie).
female(maggie).
female(lisa).
female(marge).
female(patty).
female(selma).
female(jackie).
male(bart).
male(homer).
male(herb).
male(burns).
male(smithers).
male(tod).
male(rod).
male(ned).
male(abraham).
/*Simpsons Family Code End*/

/*Rich Texan Surgeon Code Begin*/
occupation(joe,oral_surgeon).
occupation(sam,patent_laywer).
occupation(bill,trial_laywer).
occupation(cindy,investment_banker).
occupation(joan,civil_laywer).
occupation(len,plastic_surgeon).
occupation(lance,heart_surgeon).
occupation(frank,brain_surgeon).
occupation(charlie,plastic_surgeon).
occupation(lisa,oral_surgeon).
address(joe,houston).
address(sam,pittsburgh).
address(bill,dallas).
address(cindy,omaha).
address(joan,chicago).
address(len,college_station).
address(lance,los_angeles).
address(frank,dallas).
address(charlie,houston).
address(lisa,san_antonio).
salary(joe,50000).
salary(sam,150000).
salary(bill,200000).
salary(cindy,140000).
salary(joan,80000).
salary(len,70000).
salary(lance,650000).
salary(frank,85000).
salary(charlie,120000).
salary(lisa,190000).
sub_string(X,S) :- append(_,T,S) , append(X,_,T) , X \= [].
surgeon(X,Y) :- sub_atom(Y, Before, Length, After, surgeon).
surgeon(X) :- occupation(X,Y), surgeon(X,Y).
texan(X) :- address(X,Y), 
(Y==houston ; Y==dallas ; Y == college_station ; Y == san_antonio).
rich(X) :- salary(X,Y), Y>100000.
richTexanSurgeon(X) :- rich(X), surgeon(X), texan(X).
/*Rich Texan Surgeon Code End*/

/*Teacher Qualifications Begin*/
subject(algebra,math).
subject(calculus,math).
subject(dynamics,physics).
subject(electromagnetism,physics).
subject(nuclear,physics).
subject(organic,chemistry).
subject(inorganic,chemistry).
degree(bill,phd,chemistry).
degree(john,bs,math).
degree(chuck,ms,physics).
degree(susan,phd,math).
retired(bill).

canTeach(X,Z) :- degree(X,Y,Z), Y=phd.
canTeach2(X,Z) :- degree(X,Y,Z), (Y=phd ; Y=ms).
canTeach3(X,Z) :- degree(X,Y,Z), (Y=phd ; Y=ms), \+ retired(X).
/*Teacher Qualifications End*/

/*Count Up Begin*/
countup1(B,B) :- format('~w~n',[B]).
countup1(A,B) :- B>A,C is B-1,countup1(A,C),format('~w~n',[B]).

countup2(A,B) :- countup2(A,B,B).
countup2(A,B,A) :- format('~w~n',[B]).
countup2(A,B,C) :- C>A,M is C-1,X is B-C+A, format('~w~n',[X]),countup2(A,B,M).

countup3(B,B) :- format('~w~n',[B]).
countup3(A,B) :- A<B,format('~w~n',[A]),C is A+1,countup3(C,B).
/*Count Up End*/
