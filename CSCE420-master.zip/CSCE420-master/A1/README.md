# A* Implementation (CSCE 420-500)
## Zachary Knight Lewis
This program runs from the command line and uses the following 
format for its arguments:


```javascript
./[Executable] -f [FileID] -n [Iteration Limit] -t [Transcript(Yes=1/No=0)] -w [Write(Yes=1/No=0)]
```
## Arguments and Usage
The FileID is the middle three characters of the provided .bwp files. To run probB18.bwp, you would type in B18 in place of FileID. 

The Iteration Limit is the number of times the A* algorithm is allowed to run before premptively terminating. The default and recomended value is 15000.

The Transcript Boolean is a 1 or 0 value that represents 1 if the user wishes to save a transcript of the process and 0 otherwise. If the user responds with yes, a .txt file will be created, providing the user statisitcs & path of the event. If the user responds with no, the terminal outputs the path instead of writing it to a file.

The Write Boolean is a 1 or 0 value that represents 1 if the user wishes to write their final statisitc and 0 otherwise. If the user responds with yes, either a new results.txt file will be creater if one does not already exist or the new statisitcs will be appended to results.txt. If the user responsds with no, the the terminal outputs the statistic instead of writing it to a file.

The only required argument is the FileID. Every other already has a default. 15000, 0, and 0 respectively.

## What it Does

This program runs the A* algorithm using a custom Heuristic Algorithm. The algorithm collects all of the mismatched blocks into a stack and prioritizes a single block as the "current block" in order to limit the complexity of the function. 
Using this "current block" the function checks if anything is blocking the block or the spot of the block, and calcualtes a heuristic using this information. 
Additionally, because of the fact that a more evenly distributed state is easier to move than a state with a single columb of blocks, the algorithm also takes into account the total height of all blocks.
Finally, the algorithm takes into account the number of mismatched blocks. Combining these sub-functions in order to create a more complex function, we get our heuristic for A*.

The algorithm inserts the given .blk data into the Root and Goal nodes and runs A* with the nodes as its arguments.
The root node exits a priority queue and discovers it's children, saving them in a priority queue.
The priority queue sorts runs using the Heuristic + the depth of the node. Finally, previous grids are saved into a hashmap and
compared to the root node whenever neccessary. After running A*, either the maximum iteration is allotted and the function ends
with a failure, or the path is displayed on the terminal. 
If the boolean arguments are given as 1s, the transcript or result.txt is given in the directory of the executable.

## Limitations
While the algorithm is extremely quick (All of the problems calcualted in under a minute), it is extremely resource intensive due to
it's use of hashtables for fast searches and comparisons. It might be possible that certain computers cannot run the program due to a lack of hardware. Additionally, the speed of the algorithm is heavily dependent on the starting position, as the algorithm itself relies on prioritizing a single block in order to reduce complexity. However, that can backfire in certain fringe-cases like with B16 and B19.
