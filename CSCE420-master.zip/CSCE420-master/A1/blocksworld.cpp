#include <queue>
#include <stack>
#include <fstream>
#include "blockNode.h"
#include <unistd.h>
#include <string>
#include <cstring>
#include <stdio.h>

std::vector<StateNode> parse(std::string filename){
  std::vector<std::vector<Block>> rootTable = {};
  std::vector<std::vector<Block>> goalTable = {};
  StateNode root;
  StateNode goal;
  std::vector<StateNode> alphaOmega;
  int table = -1;
  std::string line;
  std::ifstream myfile ("./probs/prob"+filename+".bwp");
  if (myfile){
    if (myfile.is_open()){
        int i = 0;
        while (getline (myfile,line) ){
            if ((isalpha(line[0]) || !line[0]) && (table == 0)){
                rootTable.push_back({std::vector<Block>()});
                if (line.size()){
                    for (int c = 0; c < line.size(); c++){
                        Block x;
                        x.letter = line[c];
                        x.height = c; 
                        x.width = i;
                        rootTable[i].push_back(x);
                    }
                }
                i++;
            }
            else if ((isalpha(line[0]) || !line[0]) && (table == 1)){
                goalTable.push_back(std::vector<Block>());
                if (line.size()){
                    for (int c = 0; c < line.size(); c++){
                        Block x;
                        x.letter = line[c];
                        x.height = c; 
                        x.width = i;
                        goalTable[i].push_back(x);
                        root.fillLetter(x); // Save all blockstates in root node for comparison purposesS
                    }
                }
                i++;
            }
            if (line[0] == '>'){
                table++;
                i = 0;
                if (table > 1)
                    break;
            }
        }
        root.initalizeMap(rootTable);
        alphaOmega.push_back(root);
        goal.initalizeMap(goalTable);
        alphaOmega.push_back(goal);
        myfile.close();
    }else{std::cout << "Error: Unable to Open File"; exit(0);}
    return alphaOmega;
  }else{std::cout << "Error: File Not Found" << std::endl; exit(0);
  }
}
bool trace = 0;
int limit = 15000;
int maxQ = 1;
int count = 0;
std::string fileName = "";
StateNode a_Star(StateNode rootNode, StateNode goalNode){ // A* Implementation
    std::priority_queue<StateNode,std::vector<StateNode>,std::greater<StateNode>> frontier; 
    // The minimum value f(x) pops out first
    std::unordered_map<std::vector<std::vector<Block>>, StateNode> reached; 
    // Hashes the 2d grid and saves the node into the table for lookup
    frontier.push(rootNode);
    reached[rootNode.getgridMap()] = rootNode;
    while (!frontier.empty() && count < limit){ // Hardware limit
       StateNode* curr = new StateNode(frontier.top());
       frontier.pop();
       if (*curr == goalNode) 
            return curr;
       curr->findChildren();
        for (auto i : curr->getChildren()){
            auto kidState = i.getgridMap();
            if (reached.find(kidState) == reached.end()){
                reached[kidState] = i;
                frontier.push(i);
            }else if (reached.find(kidState)->second < i){
                reached[kidState] = i;
                frontier.push(i);
            }
            if (frontier.size() > maxQ) // Saves the most recent push
                maxQ = frontier.size();
        }
        count++;
    }
    return rootNode;
}
int main(int argc, char** argv)
{
    std::stack<StateNode> output;
    std::vector<StateNode> states;
    int option = -1;
    bool write = 0;
    while ((option = getopt (argc, argv, "f:n:w:t:")) != -1){
         switch (option){
         case 'n':
             limit = std::stoi(optarg);
             break;
         case 'f':
             fileName = optarg;
             break;
        case 'w':
             write = std::stoi(optarg);
             break;
         case 't':
             trace = std::stoi(optarg);
             break;
         default:
              break;
         }
    }
    if (fileName.size())
          states = parse(fileName);
    else{
        std::cout<<"Error: No File Given" << std::endl;
        return 0;
    }
    StateNode* root = new StateNode(states[0]);
    StateNode* goal = new StateNode(states[1]);
    root->initalizeData(root->getgridMap(), goal);
    root->findChildren();
    StateNode finalState = a_Star(*root, *goal);
    StateNode* curr = &finalState;
    if (finalState == *root && !(finalState == *goal)){
        if (!write){
            std::cout << "[STATISTICS prob" + fileName +".bwp A*] FAILED" + ", Iterations: " + 
            std::to_string(count) + ", MaxQ: " + std::to_string(maxQ) + '\n';
            return 0;
        }else{
            freopen("RESULTS.txt","a",stdout);
            std::cout << "[STATISTICS prob" + fileName +".bwp A*] FAILED" + ", Iterations: " + 
            std::to_string(count) + ", MaxQ: " + std::to_string(maxQ) + '\n';
            return 0;
        }
    }
    std::string outputEnd = "[STATISTICS prob" + fileName +".bwp A*] Planned-Length: " + std::to_string(curr->getPathCost()) + ", Iterations: " + 
    std::to_string(count) + ", MaxQ: " + std::to_string(maxQ) + '\n';
    if (!trace){
        std::cout << ">>>>>>>>>>" << std::endl;
        while (curr != nullptr){
            output.push(curr);
            curr = curr->getParent();
        }
        while (output.size()){
            std::cout << output.top();
            output.pop();
        }
    }else{
        freopen(("prob"+fileName+".transcript.txt").c_str(),"w",stdout);
        std::cout << ">>>>>>>>>>" << std::endl;
        while (curr != nullptr){
            output.push(curr);
            curr = curr->getParent();
        }
        while (output.size()){
            std::cout << output.top();
            output.pop();
        }
        std::cout << outputEnd;
    }
    if (!write){
        std::cout << outputEnd;
    }else{
        freopen("RESULTS.txt","a",stdout);
        std::cout << outputEnd;
    }
}