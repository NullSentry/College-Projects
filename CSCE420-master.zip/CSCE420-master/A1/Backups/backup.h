#ifndef BLOCKNODE_H // REDO THE ENTIRE HEURISTIC
#define BLOCKNODE_H
#include <iostream>
#include <cmath>
#include <unordered_map>

struct Block {
  char letter;
  int height;
  int width;
  bool matched = false;
  bool operator!=(const Block& rhs){ // Use this for location comparisons
      return (height != rhs.height) || (width != rhs.width) || (letter != rhs.letter);
  }
  bool operator==(const Block& rhs) const{ // Not the same as equals, as this is used for the hash function
        return letter == rhs.letter;
  }
};

template<> // Hash table for grids
struct std::hash<std::vector<std::vector<Block>>>
{
    std::size_t operator()(std::vector<std::vector<Block>> const& vec) const {
    int hash = 0;
    for (int i = 0; i < vec.size(); i++)
    for (int j = 0; j < vec[i].size(); j++)
            hash = (hash) ^ (int)((std::pow(5,i)+std::pow(7,j)))* vec[i][j].letter;
      return hash;
    }
};

class StateNode
{
    private:
        std::unordered_map<char,Block> blockSet;
        StateNode* parent;
        StateNode* goal;
        int frontier;
        int nonMatches;
        bool letterBlocked;
        bool spotBlocked;
        int pathCost;
        int max;
        int heightSum;
        std::vector<StateNode> children; 
        // Find all possible permutations of current node
        // Block NullBlock; (maybe useful for later?)
        std::vector<std::vector<Block>> gridMap;
    public:
        StateNode(): frontier(0), nonMatches(0), letterBlocked(0), spotBlocked(0), pathCost(-1), max(0),  heightSum(0), children({}), gridMap({}), blockSet({}), parent(0), goal(0) {}
        StateNode(const StateNode *node){frontier = node->frontier; nonMatches = node->nonMatches, letterBlocked = node->letterBlocked;
        spotBlocked = node->spotBlocked; pathCost = node->pathCost; max = node->max; heightSum = node->heightSum;
        gridMap = node->gridMap; blockSet = node->blockSet; parent = node->parent; goal = node->goal;}
        ~StateNode(){}
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        void findData(){ // Calculates our estimated path-value and saves it
            pathCost++;
             // When you create a new node, increase branch level [g(n)]
            std::vector<char> remMatches = {};
            for (auto i : gridMap) // Calculates our remaining nonmatches
                for (auto j : i)
                    if (j != blockSet[j.letter])
                        remMatches.push_back(j.letter);
            nonMatches = remMatches.size();
            heightSum = 0;
            bool flag = false;
            letterBlocked = 1;
            spotBlocked = 0; 
            if (remMatches.size()){ // If not in the goal-state...
                // We set the last letter in our stack as our "current-block"
                // This is to allow us to focus on one solution at a time.
                // If a permutation happens that requires us to undo a solution, it gets added back into the stack. 
                int w = blockSet[remMatches.back()].width;
                int h = blockSet[remMatches.back()].height;
                for  (auto i : gridMap){ // Iterate through column 0-N.
                    if (i.size()){
                        for  (auto j : i){ // Iterate through row 0-M.
                                heightSum += j.height; 
                                if (gridMap[w].size())
                                    if ((remMatches.back() != gridMap[w][h].letter) && (gridMap[w][h].letter))
                                        spotBlocked = 1;
                                // Find current goal-state that is blocked by an incorrect letter
                        }
                        if (i.back().letter == remMatches.back()){ // If i[0-M] is not the desired letter, the desired letter is trapped
                            letterBlocked = 0;
                        }
                    }
                }
                frontier = 2*spotBlocked + 2*letterBlocked + heightSum/3 + 2*nonMatches + pathCost; // F(n) = H(n) + G(n)
                //frontier = pathCost;
                // +2 for every goal-spot that is not empty yet & not equal to a solution.
                // +2 for our "current letter" we want to find a solution for if our current letter-block we wish to solve is blocked
                // +1/3 for sum of all block height values, as naturally we are able to easily move more blocks if they are spread about 
                // => (lower height total)
                // +2 for every mismatch
                // +1 for our pathcost
            }else{
                frontier = pathCost;
                // If we match, our heuristic is zero.
            }
        }
        void findChildren(){ // Calculates all possible permutations of current node and saves them as children
            for  (int i = 0; i < gridMap.size(); i++){ // Goes through all of the top-blocks in parent node (Only travels once since only tops can move)
                for  (int j = 0; j < gridMap.size(); j++){ // Discovers all of the potential top-block movements a child can make
                        StateNode *child = new StateNode(*this); 
                        //std::cout << getHeightSum() << std::endl;
                        //std::cout << child.getHeightSum() << std::endl;
                        auto childMap = child->getgridMap(); 
                        //std::cout << childMap[0] << std::endl;
                        if (i != j && !childMap[i].empty()){
                            if (!childMap[i].back().matched){
                                child->setParent(this);
                                childMap[j].push_back(childMap[i].back());
                                childMap[j].back().height = childMap[j].size()-1;
                                childMap[j].back().width = j;
                                childMap[i].pop_back();
                                child->updateDataMap(childMap);
                                children.push_back(child);
                            }
                        }
                }
            }
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        std::vector<std::vector<Block>> getgridMap(){ // Grabs grid of current node
            return gridMap; // Done
        }
        int getPathCost(){ // Grabs distance of the current node from the root node
            return pathCost; // Done
        }
        void updateDataMap(std::vector<std::vector<Block>> newMap){ // Updates the grid and heuristic
            gridMap = newMap;
            findData(); // Done
        }
        void initalizeData(std::vector<std::vector<Block>> newMap, StateNode* g){ // Once graph is initalized, starts running the heuristic
            goal = g;
            findData(); // Done
        } // Done
        void initalizeMap(std::vector<std::vector<Block>> newMap){ // Initalizes the grid before running our heuristic algorithm
            gridMap = newMap;
        } // Done
        std::vector<StateNode> getChildren(){ // Used in A* to populate queue
            return children;
        } // Done
        void setParent(StateNode* x){ // Saves the parent node
            parent = x;
        }
        StateNode* getParent(){ // Used for the final output.
            return parent;
        } // Done
        friend std::ostream& operator<<(std::ostream& os, const StateNode& sn){ // Prints our graph in the required format
            for (int i = 0; i < sn.gridMap.size(); i++){
                for (int j = 0; j < sn.gridMap[i].size(); j++){
                    os << "[" << sn.gridMap[i][j].letter << + "] ";
                    if (j == sn.gridMap[i].size()-1)
                    os << std::endl;
                } 
                if (!sn.gridMap[i].size()){
                    os << std::endl;
                }
            }
            return os;
        } // Done
        void print(){ // Print function prints extra items versus the operator overload
            std::cout << *this << ">>>>>>>>>>" << std::endl;
        } // Done
        void fillLetter(Block blk){ // Save our goal-state letters in a hashmap for quicker comparisons
            blockSet[blk.letter] = blk;
        } // Done
        bool operator<(const StateNode& rhs) const // Needed for replacing hashmap values 
        {
            return frontier < rhs.frontier;
        } // Done
        bool operator==(const StateNode& rhs) const // Needed for hashmap keys goal-state comparison
        {
            return gridMap == rhs.gridMap;
        } // Done
        bool operator>(const StateNode& rhs) const // Needed for sorting our priority queue
        {
            return frontier > rhs.frontier;
        } // Done
};

#endif /* MY_CLASS_H */