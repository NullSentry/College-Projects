import sys


def funPrint(x, coordx, coordy, k):
    size = coordx+coordy
    cnf = ""
    i = k
    for n in range(len(x)):
        for m in range(len(x[0])):
            # Non solutions:
            # Pcurr -> (-Pnm ^ -Pnm ^ -Pnm ^ ...^ -Pnm)
            # -Pcurr v (-Pnm ^ -Pnm ^ -Pnm ^ ...^ -Pnm)
            # (-Pcurr v -Pnm) ^ (-Pcurr v -Pnm) ^ ... ^ (-Pcurr v -Pnm)
            if (coordx == m):
                x[n][m] = str(n) + str(m)
            if (coordy == n):
                x[n][m] = str(n) + str(m)
            if ((coordy - n) == (coordx - m)):
                x[n][m] = str(n) + str(m)
            if ((size-n) == (size-m)):
                if (len(x) > (size-n) and (size-n) >= 0):
                    x[size-n][m] = str(size-n) + str(m)
                    x[m][size-n] = str(m) + str(size-n)
            if (coordy == n and coordx == m):
                x[n][m] = "oo"
            if (x[n][m] == "xx"):
                # Solutions:
                # (Pxx v Pxx v Pxx v ... v Pxx)
                x[n][m] = "xx"
            print(x[n][m]+" ", end='')
        print("")
    print("")
    for n in x:
        for m in n: 
            if (m != "xx" and (m!="oo")):
                    if (m!=(str(coordy)+str(coordx))):
                        cnf +="-Q" + str(coordx)+str(coordy) + " -Q"+m[::-1]+"\n"
                        i+=1
    #print(cnf)
    return (cnf,i)

def main(n):
    k = 0
    board = ["xx"] * n
    for i in range(n):
        board[i] = ["xx"] * n
    cnfLarge = ""
    for i in range(len(board)):
        #cnfLarge += str(k) + ". "
        k+=1
        for j in range(len(board[0])):
            cnfLarge+= "Q"+str(i)+str(j)+" "
        cnfLarge = cnfLarge[:-1]
        cnfLarge += '\n'
    for i in range(len(board)):
        for j in range(len(board[0])):
            for k in range(len(board)):
                for l in range(len(board[0])):
                    board[k][l] = "xx"
            pairs = funPrint(board, i, j, k)
            cnfLarge+= pairs[0]
            k=pairs[1]
    cnfLarge = cnfLarge[:-1]
    #print(cnfLarge)
    f = open(str(n)+"Queens.cnf", "w")
    f.write(cnfLarge)
    f.close()

if __name__=="__main__":
    if ((len(sys.argv) > 1) and sys.argv[1].isnumeric() and (int(sys.argv[1]) > 0)):
        n = int(sys.argv[1])
    elif (len(sys.argv) == 1):
        n = 8
    else:
        print("Error: Invalid Argument.")
        exit()
    main(n)