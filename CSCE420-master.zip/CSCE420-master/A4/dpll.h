#ifndef DPLL_H 
#define DPLL_H
#include <iostream>
#include <unordered_map>
#include<vector>
#include <algorithm> 
struct symbol {
  std::string letter;
  bool negation = false;
  int value = 0; // -1 is false, 1 is true, 0 is null
  // output of || is not the same (-1=F, 1=T, 0=N vs -1=N, 1=T, 0=F)
  // Or is designed to be consistent with the output of the normal || operator (plus a -1 for a null result).
  // value has a different notation to make math easier
  bool operator==(const symbol& rhs) const{
        return (letter == rhs.letter);
  }
  int operator||(const int& rhs) const{
        if (value == 0 || rhs == -1){
            return -1;
        }
        if (value == -1){
            return 0+rhs;
        }else{
            return 1;
        }
  }
  
  void quantify(int x=1){
      if (x > 0)
        value = 1;
      if (x == 0)
        value = 0;
      if (x < 0)
        value = -1;
      if (negation)
        value*=-1;
    } 
};

class CNF
{
    private:
        std::vector<std::vector<symbol>> clauses; // Change parser to make letter equal positive variant (without -). Just make the negation true.
        std::unordered_map<std::string,int> model; // Remember to populate all values as null in advance before running algorithm
        std::vector<std::string> symbols;
    public:
        CNF(): clauses({}), model({}), symbols({}){}
        CNF(const CNF *cnf){clauses = cnf->clauses; model = cnf->model, symbols = cnf->symbols;}
        CNF(std::vector<std::vector<symbol>> x,std::unordered_map<std::string,int> y,std::vector<std::string> z){clauses = x; model = y; symbols = z;}
        ~CNF(){}
        std::vector<std::vector<symbol>> grabClauses(){
            return clauses;
        }
        std::unordered_map<std::string,int> grabModel(){
            return model;
        }
        std::vector<std::string> grabSymbols(){
            return symbols;
        }
        symbol findUnitClause(){
            int idx;
            symbol s;
            s.letter = "";
            s.value = 0;
            for (int i = 0; i < clauses.size(); i++){
                int unknowns = 0;
                int falses = 0;
                for (auto j : clauses[i]){
                    if (j.value == -1)
                        falses++;
                    if (j.value == 0){
                        idx = falses+unknowns;
                        unknowns++;
                    }
                }
                if ((unknowns == 1) && (falses == clauses[i].size()-1) && (clauses[i][idx].value == 0)){
                    clauses[i][idx].quantify(1);
                    s.value = clauses[i][idx].value;
                    s.letter = clauses[i][idx].letter;
                    model[clauses[i][idx].letter] = clauses[i][idx].value;
                    for (int x = 0; x < clauses.size(); x++){
                    for (int y = 0; y < clauses[x].size(); y++){
                            if (clauses[x][y] == s)
                                clauses[x][y].quantify(s.value);
                        }
                    }
                    symbols.erase(find(symbols.begin(), symbols.end(), s.letter));
                    return clauses[i][idx];
                }
            }
            return s;
        }
        void symVal(int v){
            std::string s = symbols.back();
            model[s] = v;
            symbols.pop_back();
            for (int x = 0; x < clauses.size(); x++){
            for (int y = 0; y < clauses[x].size(); y++){
                    if (clauses[x][y].letter == s)
                        clauses[x][y].quantify(v);
                }
            }
        }
        bool goodModel (){
            for (auto i : clauses){
                int clause = 0;
                for (auto j : i){
                    clause = (j||clause);
                }
                if (clause != 1) 
                    return 0;
            }
            return 1;
        }

        bool badModel (){
        for (auto i : clauses){
            int clause = 0;
            for (auto j : i){
                clause = (j||clause);
            }
            if (clause == 0) 
                return 1;
            }
            return 0;
        }
};

#endif