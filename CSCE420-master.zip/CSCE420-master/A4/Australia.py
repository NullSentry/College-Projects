aus = [["WA","NT", "SA"],
["NT", "WA", "SA", "QU"],
["QU", "NT", "NS", "SA"],
["SA", "WA", "NT", "QU", "NS", "VI"],
["VI", "NS", "SA"],
["NS", "QU", "SA", "VI"],
["TA"]]
colors = ["R", "G", "B"]
def funPrint(x):
    cnf = ""
    i = 0
    for n in x:
        i+=1
        for c in colors:
            cnf += n[0]+c+" "
        cnf = cnf[:-1]
        cnf += '\n'
    for n in range(len(x)):
        for c in colors:
            for c2 in colors:
                for m in range(len(x[n])):
                    if (m == 0 and c2 != c):
                        i+=1
                        cnf += "-"
                        cnf += x[n][0] + c +" -" + str(x[n][m]) + c2 + "\n" 
                    if (m != 0 and c2 == c):
                        i+=1
                        cnf += "-"
                        cnf += x[n][0] + c +" -" + str(x[n][m]) + c2 + "\n" 
    cnf += "WAR"
    f = open("mapcolor.cnf", "w")
    f.write(cnf)
    f.close()
    cnf = cnf[:-3]
    cnf+="WAB"
    f = open("mapcolor2.cnf", "w")
    f.write(cnf)
    f.close()
    print(cnf)

funPrint(aus)