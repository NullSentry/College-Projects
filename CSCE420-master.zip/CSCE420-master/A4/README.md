# DPLL Implementation (CSCE 420-500)
## Zachary Knight Lewis
This program runs from the command line and uses the following 
format for its arguments:


```javascript
./[Executable] -f [FileID] -r [result(Print=0, Append=1, New=2)] -t [Transcript(Yes=1/No=0)] -UCH
```
## Arguments and Usage
The FileID is the name of the .cnf file. If an arbitrary cnf file such as "example.cnf" exists the same folder as the program, the user would type "example".

The result integer is how the results will be output. If the user types "-r 0" (or input no -r), you just output the results to the terminal. If the user types "-r 1", either a new RESULTS.txt file will be created (if it does not exist) or the new data will be appended to REUSLTS.txt. If the user types "-r 2", either a new RESULTS.txt file will be created (if it does not exist) or the new data will overwrite the old RESULTS.txt file.

The Transcript Boolean is a 1 or 0 value that represents 1 if the user wishes to save a transcript of the process and 0 otherwise. If the user responds with yes, a .txt file will be created, providing the user the model calcualted from the DPLL algorithm. If the user responds with no (or inputs no -t), no transcript is provided.

The UCH flag is command flag that tells the program to NOT run the DPLL algorithm with the Unit-Clause Heuristic if given. If the user does not provid this flag, the program will run the DPLL algorithm with the Unit-Clause Heuristic. Additionally, the results function (either via output or in RESULTS.txt) provides the user info on if the UCH ran or not depending on this flag.

The only required argument is the FileID. Every other already has a default. 0, 0, and UCH-ON respectively.

## What it Does

This program runs the DPLL algorithm. Grabs the CNF data from the given .cnf file and creates the clauses list (representing each line of the CNF), the model set (the required T/F value for each symbol), and the symbols list (the remaining symbols that need to be analyzed). These items are created in v, m, and sym respectively and are created from the fileParse function. The symbol values inside the models and clauses items are defaulted to a null value, as no calculations on their validity have been done yet.
These items are then run through the DPLL algorithm, which updates clauses and models with true/false respective to the current symbol from the symbols list. If the current symbol in symbols is "A", all "A" values are updated in models and clauses.

This is recursively done until either a contradiction happens (which results in returning a nullptr) or a solution is found (which results in returning the final dataset). Afterwards, the values are recorded and the transcript function and results function run accordingly.

## Limitations
There might be some glitches with the command line arguments. Other than that, everything seems to work as intended.
