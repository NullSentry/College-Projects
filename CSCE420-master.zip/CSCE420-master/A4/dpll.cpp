#include "dpll.h"
#include <fstream>
#include <sstream>
#include <unistd.h>
#include <getopt.h>
std::vector<std::vector<symbol>> v; // Change parser to make letter equal positive variant (without -). Just make the negation true.
std::unordered_map<std::string,int> m; // Remember to populate all values as null in advance before running algorithm
std::vector<std::string> sym;
bool uch = true; 
int iter = 0;
void lineParse(std::string line){
    symbol s;
    std::string clause;
    std::stringstream ss;
    ss << line;
    while (ss >> clause){ 
        //std::cout << clause << '\n';
        if (clause.at(0) == '-' && clause.size() > 1){
            s.letter = &clause[1];
            s.negation = true;
            s.value = 0;
        }else{
            s.letter = clause;
            s.negation = false;
            s.value = 0;
        }
        v.back().push_back(s);
        if (m.find(s.letter) == m.end()){
          s.negation = false;
          m[s.letter] = 0;
          sym.push_back(s.letter);
        }

    }
}

void fileParse(std::string filename){
  std::string line;
  std::ifstream in (filename+".cnf");
  if (in.is_open())
  {
    while (getline(in,line) )
    {
      size_t i = line.find("#");
      if (i != std::string::npos)
        line = line.substr(0, i);
      if (line.size()){
        v.push_back({});
        lineParse(line);
      }
      //std::cout << "----------" << '\n';
    }
    in.close();
  }else{
    std::cout << "Error: invalid filename." << '\n';
    exit(0);
  }
}

CNF* dpll(std::vector<std::vector<symbol>> x = v, std::unordered_map<std::string,int> y = m, std::vector<std::string> z = sym){
  iter++;
  CNF* data = new CNF(x,y,z);
  CNF* data2 = new CNF(x,y,z);
  symbol s;
  std::string letter;
  if (data->goodModel() == 1){
    return data;}
  if (data->badModel())
    return nullptr;
  if (uch){
    s = data->findUnitClause();
    if (s.value){
      x = data->grabClauses();
      y = data->grabModel();
      z = data2->grabSymbols();
      return dpll(x, y, z);
    }
  }
  
  if (z.size()){
    data->symVal(1);
    x = data->grabClauses();
    y = data->grabModel();
    z = data->grabSymbols();
    data = dpll(x,y,z);
    if (data == nullptr){
      data2->symVal(-1);
      x = data2->grabClauses();
      y = data2->grabModel();
      z = data2->grabSymbols();
      data = dpll(x,y,z);
    }
  }
  return data;
}

void transcribe(std::string t, std::string f){
  std::ofstream out;
  if (uch){
    out.open (f+".transcript.txt",std::ios::out);
    
  }else{
    out.open (f+"-UCH.transcript.txt",std::ios::out);
  }
  out << t;
  out.close();
}

void resulting(std::string r, int n){
  if (n == 1){
    std::ofstream out;
    out.open ("RESULTS.txt", std::ios::app);
    out << r;
    out.close();
  }
  if (n == 2){
    std::ofstream out;
    out.open ("RESULTS.txt", std::ios::out | std::ofstream::trunc);
    out << r;
    out.close();
  }
}

int main(int argc, char** argv)
{
    int option = -1;
    int r = 0;
    bool t = 0;
    std::string name = "";
    std::string result = "";
    std::string transcript = "";
    for (int i = 0; i < argc; i++){
        std::string str = argv[i];
        if (str == "-UCH"){
          uch = 0;
        }
    }
    while ((option = getopt (argc, argv, ":f:r:t")) != -1){
      switch (option){
        case 'f':
          name = optarg;
          break;
        case 'r':
            r = std::stoi(optarg);
          break;
        case 't':
            t = 1;
            break;
        default:
          break;
      }
    }
    if (!name.size()){
      std::cout << "Error: no filename given." << '\n';
      exit(0);
    }
    fileParse(name);
    dpll();
    CNF* x = dpll();
    if (x != nullptr){
      for (auto i :x->grabModel())
        if (i.second == 1)
          transcript += i.first + ", T" + '\n';
        else if (i.second == -1)
          transcript += i.first + ", F" + '\n';
        else
          transcript += i.first + ", ?" + '\n';
      //std::cout << transcript << '\n';
    }
    else
        transcript += "No solution.\n";
    if (uch)
      result += "Filename: "+ name + ".cnf\n"  + "Number of iterations[UCH-ON]: " + std::to_string(iter) + "\n"+ transcript + "----------------------------------\n";
    else
      result += "Filename: "+ name + ".cnf\n"  + "Number of iterations[UCH-OFF]: "  + std::to_string(iter) + "\n"+ transcript + "----------------------------------\n";
    if (t)
      transcribe(transcript, name);
    if (r == 1)
      resulting(result, r);
    if (r == 2)
      resulting(result, r);
    if (r == 0)
      std::cout<<result;
}