#include "tttBoard.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
int iter = 0;
int transcript = 0;
bool results = 0;
int rnd = 0;
std::string upString(std::string &s){
    for (int i = 0; i < s.size(); i++)
        s[i] = toupper(s[i]);
    
    return s;
}

std::string parse(std::string &s){
    upString(s);
    std::string s2;
    for (int i = 0; i < s.size(); i++)
        if (s[i] != ' ')
            s2+=s[i];
    s = s2;
    return s;
}
int main(int argc, char** argv){
    int option = -1;
    bool cases = 0;
    gameBoard b = new gameBoard();
    while ((option = getopt (argc, argv, "t:rpc")) != -1){
         switch (option){
         case 't':
             transcript = std::stoi(optarg);
             break;
         case 'r':
             results = 1;
             break;
        case 'p':
             b.prune(1);
             break;
        case 'c':
             cases = 1;
             break;
        default:
              break;
         }
    }
    if ((transcript == 5) || (transcript == 1))
        rnd = 1;
    if (cases){
        if ((transcript > 0) && (transcript < 6)){
            //freopen(("Transcript"+std::string(std::to_string(transcript))+".txt").c_str(),"a",stdout);
            std::ofstream trscript;
            trscript.open (("Transcript"+std::string(std::to_string(transcript))+".txt").c_str(), std::ios_base::app);
            trscript << "Pruning: " << b.isPruning() << std::endl;
            trscript.close();
        }
        switch (transcript){
            case 1:
                break;
            case 2:
                //std::cout << "Move: " << "(B,2)" << std::endl;
                b.move('X','B',2, 1);
                break;
            case 3:
                //std::cout << "Move: " << "(A,1)" << std::endl;
                b.move('X','A',1, 1);
                break;
            case 4:
                //std::cout << "Move: " << "(A,2)" << std::endl;
                b.move('X','A',2, 1);
                break;
            case 5:
                //std::cout << "Move: " << "(B,2)" << std::endl;
                b.move('X','B',2, 1);
                //std::cout << "Move: " << "(A,2)" << std::endl;
                b.move('O','A',2, 1);
                break;
            default:
                std::cout << "Error: Invalid Transcript Value" << std::endl;
                return 0;
        }
        while (!b.endGame('X').first){
            if ((rnd%2) == 1)
                b = b.choose('X');
            else
                b = b.choose('O');
            rnd++;
            iter = 0;
        }
        std::ofstream trscript;
        trscript.open (("Transcript"+std::string(std::to_string(transcript))+".txt").c_str(), std::ios_base::app);
        trscript << "------------------------------" << std::endl;
        trscript.close();
        return 0;
    }
    if (transcript){
            //freopen(("Transcript"+std::string(std::to_string(transcript))+".txt").c_str(),"a",stdout);
            std::ofstream trscript;
            trscript.open (("Transcript"+std::string(std::to_string(transcript))+".txt").c_str(), std::ios_base::app);
            trscript << "Pruning: " << b.isPruning() << std::endl;
            trscript.close();
    }
    std::cout << "Welcome to Tic-Tac-Toe" << std::endl;
    std::cout << "Please Input a Command:" << std::endl;
    std::cout << "-----" << std::endl; /**/
    std::cout << b;
    std::cout << "-----" << std::endl; /**/
    std::string input = "";
    std::getline (std::cin,input);
    while (input.size() && (input != "quit")){
        parse(input);
        if (!input.compare(0, 4, "MOVE")){
            iter = 0;
            b.move(input[4],input[5], (int)(input[6]-'0'), 1);
        }
        if (!input.compare(0, 6, "CHOOSE")){
            iter = 0;
            b = b.choose(input[6]);
        }
        if (!input.compare("RESET"))
            b.reset();
        if (!input.compare(0, 7,"PRUNING")){
            if (input.size() > 7){
                if (!input.compare(7,input.size(),"ON") || (input[7] == '1')){
                    std::cout << "Pruning set to ON" << std::endl;
                    b.prune(1);
                }
                else if (!input.compare(7,input.size(),"OFF") || (input[7] == '0')){
                    std::cout << "Pruning set to OFF" << std::endl;
                    b.prune(0);
                }
            }else{
                std::cout << "Pruning Status: " << b.isPruning() << std::endl;
                
            }
        }
        //std::cout << input.size() << std::endl;
        std::cout << "Please Input a Command:" << std::endl;
        std::cout << "-----" << std::endl; /**/
        std::cout << b; /**/
        std::cout << "-----" << std::endl; /**/
        if (!input.compare("SHOW"))
            b.show();
        if (b.endGame('X').first){
            std::cout << "-----" << std::endl; /**/
            std::cout << b; /**/
            std::cout << "-----" << std::endl; /**/
            std::cout << "GAME OVER" <<std::endl;
            std::cout << b.getWinner() << '\n' << std::endl;
            b.reset();
            std::cout << "Please Input a Command:" << std::endl;
            std::cout << "-----" << std::endl; /**/
            std::cout << b; /**/
            std::cout << "-----" << std::endl; /**/
            
        }
        std::getline (std::cin,input);
        // If transcripts = 1 then save transcripts from choose function
        // If results = 1 then do an automatic cpu fight w & w/o alpha beta
    }
    if (transcript){
        std::ofstream trscript;
        trscript.open (("Transcript"+std::string(std::to_string(transcript))+".txt").c_str(), std::ios_base::app);
        trscript << "------------------------------" << std::endl;
        trscript.close();
    }
    return 0;
}


