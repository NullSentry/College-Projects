# Minimax & Alpha-Beta TicTacToe (CSCE 420-500)
## Zachary Knight Lewis
This program runs from the command line and uses the following 
format for its arguments:


```javascript
./[Executable] -t [Transcript Value] -r -c -p
```
## Arguments and Usage
The Transcript mode (-t) argument requires an integer in its argument. If the integer is set, the algorithm runs through a given test case and saves it to a TranscriptX.txt, in which X is equal to the integer argument for the transcript mode. If the integer is set to zero or the transcript argument is not given, then the program does not transcribe anything

The Result mode (-r) argument makes it so that if the transcript mode is enabled, the result mode additionally saves the search node iterations in the Results.txt file.

The Case mode (-p) argument makes it so that instead of asking for user inputs, the program instead runs through a the test cases provided in the assignment documentation. The test case value is determined by the integer argument from (-t).

The prune argument (-p) determines if the default pruned value is zero or one. If the -p argument is given, then the default pruned value is 1. Otherwise, the default pruned value is zero. This is useful for saving the pruned and unpruned values in transcript mode, as the transcript mode does not allow user inputs.  

There are no required arguments for this code.

## Computer Optimized TicTacToe

This program runs the minimax/alpha-beta algorithm on a tictactoe game in order to determine an optimal output. The algorithm without alpha-beta goes through all possible permutations and checks the endgoals and their scores. If the computer wins, it gets a postive score. If the computer looses, it gets a negative score. If the computer draws, the score is zero. The computer assumes that the player chooses an optimal path. The computer then chooses the most optimal path with this knowlege, going for the safest high-valued option rather than the value with the highest potential. 

## Transcript Mode

In transcript mode, our transcript file is given a numeric value of. In this mode, the output of the move and choose function are given in our transcriptX.txt file. The function calls are saved into the transcript file in order of when they were called. Additionally, each round of the choose function additionally outputs the number of node iterations into the transcript file. The updated textfile also includes a statement, specifying if a minimax or alpha-beta is used.

If result mode is enabled, the details of the node iterations are also saved into the Results.txt file. Additionally, The updated textfile also includes a statement, specifying if a minimax or alpha-beta is used.

## Case Mode

In Case Mode, the function is ran through the documented example test cases as given by the transcript argument. The user mode does not activate if the case flag is activated. Additionally, if an invalid transcript value is given (less than 1 or greater than 5), then the case mode exits without saving anything.

## User Mode

If case mode is not activated, user mode is activated instead. In user mode, the user is allowed to give instructions to the program. The user has the following commands: Move (X/O) (A/B/C) (1/2/3), Choose (X/O), Pruning (On/Off/Null), Reset, Show, and Quit. The user is provided a tictactoe game and can run commands indefinitely or until the quit command is used. If a tictactoe game finishes, the winner is declared (or a draw) and the game restarts with a new tictactoe game. 

The move function allows the user to manually update the tictactoe board. If the user types "Move X A 2", the program will place an X on the tictactoe board in row 1 column 2. 

The choose function runs the minimax / alpha-beta algorithm (depending on the current prune value). The function chooses the optimal tictactoe choice as a result. If the user types "Choose X", the program will choose the optimal spot for X. 

The pruning command either outputs the on/off state of alpha-beta or enables/disables the alpha-beta. If the user types "Pruning On/Off", the pruning is enabled/disabled and the alpha-beta function is enabled/disabled. If the user types "Pruning", then the computer outputs the current state of alpha-beta.

The reset command simply resets the board and starts a new game. If the user types "Reset", the current tictactoe game is haulted and a empty tictactoe board is provided for a new game.

The show command outputs the current state of the program. If the user types "Show", the current score, the pruning boolean value, the number of nodes calculated from the last called choose function, and the current depth of the tictactoe board is output in the terminal.

The quit command ends the game. If the user types "Quit", the program is haulted.

## Limitations
The user mode is not designed to accept or correct faulty inputs. As a result, there may be unintended consequences if an improper input is provided. 