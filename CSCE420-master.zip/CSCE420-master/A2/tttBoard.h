#ifndef TTTBOARD_H 
#define TTTBOARD_H
#include <vector>
#include <ostream>
#include <iostream>
#include <fstream>
#include <cfloat>
extern int iter;
extern int transcript;
extern bool results;
extern int rnd;
class gameBoard
{
    private:
        std::vector<std::vector<char>> 
        board = {{'.','.','.'},{'.','.','.'},{'.','.','.'}};
        int depth;
        double score;
        bool pruning;
        gameBoard* parent;
        std::vector<gameBoard> children;
        std::string winner = "";
        char row;
        int col;
    public:
        //Creation
        gameBoard(): depth(0), score(0), pruning(0) {}
        //Copy
        gameBoard(const gameBoard *node){
            board = node->board;
            depth = node->depth;
            score = node->score;
            pruning = node->pruning;
            parent = node->parent;
            row = node->row;
            col = node->col;
        }
        //Destruction
        ~gameBoard(){}
        //Print Overload
        friend std::ostream& operator<<(std::ostream& os, const gameBoard& gb){
            for (auto i : gb.board){
                for (auto j : i)
                    os << j << " ";
                os << "\n";
            }
            return os;
        }
        void findChildren(char curr){
            for (int i = 0; i < board.size(); i++){
                for (int j = 0; j < board[i].size(); j++){
                    gameBoard *child = new gameBoard(*this); 
                    auto childBoard = child->getBoard();
                    if (childBoard[i][j] == '.'){
                        child->move(curr,i+97,j+1, 0);
                        child->setParent(this);
                        children.push_back(child);
                    }
                }
            }
        }
        std::vector<gameBoard> getChildren(){
            return children;
        }
        std::vector<std::vector<char>> getBoard(){ 
            return board;
        }
        void setBoard(std::vector<std::vector<char>> B){
            board = B;
        }
        void setParent(gameBoard* x){parent = x;}
        gameBoard* getParent(){return parent;}
        double currScore(){return score;}
        std::pair<bool, double> endGame(char CPU){
            for (int i = 0; i < board.size(); i++){
                if ((board[0][i] == board[1][i]) && (board[1][i] == board[2][i]) && (board[0][i] != '.')){
                    if (board[0][i] == CPU){
                       score = 1-0.1*depth;
                       if (CPU == 'X')
                            winner = "PLAYER X WINS";
                       else
                            winner = "PLAYER O WINS";
                    }else{
                       score = -1+0.1*depth;
                       if (CPU == 'X')
                            winner = "PLAYER O WINS";
                       else
                            winner = "PLAYER X WINS";
                    }
                }
                if ((board[i][0] == board[i][1]) && (board[i][1] == board[i][2]) && (board[i][1] != '.')){
                    if (board[i][0] == CPU){
                       score = 1-0.1*depth;
                       if (CPU == 'X')
                            winner = "PLAYER X WINS";
                       else
                            winner = "PLAYER O WINS";
                    }else{
                       score = -1+0.1*depth;
                       if (CPU == 'X')
                            winner = "PLAYER O WINS";
                       else
                            winner = "PLAYER X WINS";
                    }
                }
                if ((board[0][0] == board[1][1]) && (board[1][1] == board[2][2]) && (board[0][0] != '.')){
                    if (board[0][0] == CPU){
                       score = 1-0.1*depth;
                       if (CPU == 'X')
                            winner = "PLAYER X WINS";
                       else
                            winner = "PLAYER O WINS";
                    }else{
                       score = -1+0.1*depth;
                       if (CPU == 'X')
                            winner = "PLAYER O WINS";
                       else
                            winner = "PLAYER X WINS";
                    }
                }
                if ((board[0][2] == board[1][1]) && (board[1][1] == board[2][0]) && (board[0][2] != '.')){
                    if (board[0][2] == CPU){
                       score = 1-0.1*depth;
                       if (CPU == 'X')
                            winner = "PLAYER X WINS";
                       else
                            winner = "PLAYER O WINS";
                    }else{
                       score = -1+0.1*depth;
                       if (CPU == 'X')
                            winner = "PLAYER O WINS";
                       else
                            winner = "PLAYER X WINS";
                    }
                }
            }
            if ((depth == 9) || score){
                if (score == 0){
                    winner = "DRAW";
                }
                return {true, score};
            }
            return {false, score};
        };
        void show(){
            std::cout << "Current Score: " << score << "\nPruning: "<< pruning << "\nNumber of Nodes Searched: " 
            << iter << '\n' << "Depth: " << depth << '\n';
        }
        void move(char P, char R, int C, bool input){
            row = R;
            col = C; 
            R = tolower(R);
            if ((C < 1) || (C > 3)){
                std::cout << "Error: Invalid move, please try again." << std::endl;
                return;
            }
            switch (R){
                case 'a':
                    if (board[0][C-1] == '.'){
                        board[0][C-1] = P; 
                        depth++;
                        break;
                    }
                    std::cout << "Error: Invalid move, please try again." << std::endl;
                    break;
                case 'b':
                    if (board[1][C-1] == '.'){
                        board[1][C-1] = P;
                        depth++;
                        break;
                    }
                    std::cout << "Error: Invalid move, please try again." << std::endl;
                    break;
                case 'c':
                    if (board[2][C-1] == '.'){
                        board[2][C-1] = P;
                        depth++;
                        break;
                    }
                    std::cout << "Error: Invalid move, please try again." << std::endl;
                    break;
                default:
                    std::cout << "Error: Invalid move, please try again." << std::endl;
                    break;
            }
            if (transcript && input){
                std::ofstream trscript;
                trscript.open (("Transcript"+std::string(std::to_string(transcript))+".txt").c_str(), std::ios_base::app);
                trscript << "Move: " << "(" << R << ","+std::to_string(1)+")" << std::endl;
                trscript.close();
            }
        }
        //Choose (Piece) // Invoke minimax
        gameBoard choose(char P){
            double a = -DBL_MAX;
            double b = DBL_MAX;
            findChildren(P);
            double x = -DBL_MAX;
            std::pair<gameBoard*, double> next;
            gameBoard curr;
            //iter++;
            for (auto i : getChildren()){
                next = i.mini(P, a, b);
                if (next.second > x){
                    x = next.second;
                    a = std::max(a,x);
                    curr = i;
                }
                if (transcript)
                    printUtil(i, next.second);
                // Output to "TranscriptX.txt" file
                if ((x >= b) && pruning)
                    return curr;
            }
            if (transcript){
                std::ofstream trscript;
                trscript.open (("Transcript"+std::string(std::to_string(transcript))+".txt").c_str(), std::ios_base::app);
                trscript << "Number of Nodes Searched: " << iter << std::endl; 
                trscript.close();
                if (results){
                    std::ofstream results;
                    results.open ("Results.txt", std::ios_base::app);
                    if (!rnd || (((transcript == 5) || (transcript == 1)) && (rnd == 1))){
                        results << "Summary of Nodes Searched with Alpha-Beta Pruning " + isPruning() +  " for Game " + std::to_string(transcript) + ":" << std::endl;
                    }
                    results << "Number of Nodes Searched: " << iter << std::endl;
                    results.close();
                }
            }
            // Output to "TranscriptX.txt" file
            depth++;
            return curr;
        }
        std::pair<gameBoard*, double> maxi(char P, double a, double b){
            gameBoard* node = new gameBoard(this);
            std::pair<gameBoard*, double> curr = {node, -DBL_MAX};
            std::pair<gameBoard*, double> next;
            iter++;
            if (endGame(P).first){
                    //iter++;
                    return {node, endGame(P).second};
            }
            if (children.empty())
                node->findChildren(P);
            for (auto i :  node->getChildren()){
                next = i.mini(P,a,b);
                if (next.second > curr.second){
                    curr = next;
                    a = std::max(a,curr.second);
                }
                if ((curr.second >= b) && pruning)
                    return curr;
            }
            return curr;
        }
        std::pair<gameBoard*, double> mini(char P, double a, double b){
            gameBoard* node = new gameBoard(this);
            std::pair<gameBoard*, double> curr = {node, DBL_MAX};
            std::pair<gameBoard*, double> next;
            iter++;
            if (endGame(P).first){
                //iter++;
                return {node, endGame(P).second};
            }
            if (children.empty()){
                if (P == 'X'){
                     node->findChildren('O');
                }else{
                     node->findChildren('X');
                }
            }
            for (auto i :  node->getChildren()){
                next = i.maxi(P,a,b);
                if (next.second < curr.second){
                    curr = next;
                    b = std::min(b,curr.second);
                }
                if ((curr.second <= a) && pruning)
                    return curr;
            }
            return curr;
        }
        //Pruning() // Return if pruning or not
        std::string isPruning(){
            if (pruning)
                return "ON";
            return "OFF";
        }
        //Pruning(On/Off) // Turn pruning on or off and update calc
        void prune(bool O){pruning = O;}
        void reset(){
            board = {{'.','.','.'},{'.','.','.'},{'.','.','.'}};
            score = 0;
            parent = nullptr;
            depth = 0;
            children = {};
            winner = "";
            iter = 0;

        }
        char getRow(){return row;}
        int getCol(){return col;}
        std::string getWinner(){
            return winner;
        }
        void printUtil(gameBoard b, double s){
            std::ofstream trscript;
            trscript.open (("Transcript"+std::string(std::to_string(transcript))+".txt").c_str(), std::ios_base::app);
            trscript << "Move: (" << (char)toupper(b.getRow()) << "," << b.getCol() << ") -- Mm-score: " << s << std::endl;
            trscript.close();
        }
};
#endif