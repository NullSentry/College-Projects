#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <iostream>
#define MAX_THREADS     65536
#define MAX_LIST_SIZE   268435456

//
// Computes the minimum of a list using multiple threads
//
// Warning: Return values of calls are not checked for error to keep 
// the code simple.
//
// Compilation command on ADA ($ sign is the shell prompt):
//  $ module load intel/2017A
//  $ icc -o list_statistics.exe list_statistics.c -lpthread -lc -lrt
//
// Sample execution and output ($ sign is the shell prompt):
//  $ ./list_statistics.exe 1000000 9
// Threads = 9, minimum = 148, time (sec) =   0.0013
//

int num_threads;		// Number of threads to create - user input 

int thread_id[MAX_THREADS];	// User defined id for thread
pthread_t p_threads[MAX_THREADS];// Threads
pthread_attr_t attr;		// Thread attributes 
long global_sum;
unsigned long global_sum2;
long double global_mean;
long double global_sdev;
pthread_mutex_t lock_minimum;	// Protects minimum, count
int count;			// Count of threads that have updated minimum
int list[MAX_LIST_SIZE];	// List of values
int list_size;			// List size

// Thread routine to compute minimum of sublist assigned to thread; 
// update global value of minimum if necessary

void *find_stats (void *s) {
    int j;
    int my_thread_id = *((int *)s);
    unsigned long local_sum;
    unsigned long local_sum2;
    long double local_mean;
    int block_size = list_size/num_threads;
    int my_start = my_thread_id*block_size;
    int my_end = (my_thread_id+1)*block_size-1;
    if (my_thread_id == num_threads-1)
        my_end = list_size-1;
    int sample_size =  my_end-my_start;
    local_sum = list[my_start];
    local_sum2 = pow(list[my_start],2)/100;
    for (j = my_start+1; j <= my_end; j++){
	    local_sum += list[j];
	    local_sum2 += pow(list[j],2)/100;
    }
    local_mean = local_sum;
    pthread_mutex_lock(&lock_minimum);
    count++;
    global_sum+= local_sum;
    global_sum2+= local_sum2;
    global_mean+= local_mean/list_size;
    if (my_thread_id == num_threads-1){
        global_sdev = sqrt((global_sum2/list_size)-pow(global_mean,2)/100)*10;
    }
    pthread_mutex_unlock(&lock_minimum);
    // Thread exits
    pthread_exit(NULL);
}

// Main program - set up list of randon integers and use threads to find
// the minimum value; assign minimum value to global variable called minimum
int main(int argc, char *argv[]) {

    struct timespec start, stop;
    double total_time, time_res;
    int i, j; 
    long true_mean = 0;
    long double true_mean_final;
    unsigned long true_sdev = 0;
    long double true_sdev_final;
    list_size = 1000;
    num_threads = 15;

    // Initialize mutex and attribute structures
    pthread_mutex_init(&lock_minimum, NULL); 
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);

    // Initialize list, compute minimum to verify result
    srand48(0); 	// seed the random number generator
    list[0] = lrand48();
    true_mean += list[0];
    for (j = 1; j < list_size; j++) {
        list[j] = lrand48(); 
        true_mean += list[j];
    }
    true_mean_final = true_mean/((double)list_size);
    // Initialize count
    count = 0;
    // Create threads; each thread executes find_minimum
    clock_gettime(CLOCK_REALTIME, &start);
    for (i = 0; i < num_threads; i++) {
	thread_id[i] = i; 
	pthread_create(&p_threads[i], &attr, find_stats, (void *) &thread_id[i]); 
    }
    // Join threads
    for (i = 0; i < num_threads; i++) {
	pthread_join(p_threads[i], NULL);
    }
    // Compute time taken
    clock_gettime(CLOCK_REALTIME, &stop);
    total_time = (stop.tv_sec-start.tv_sec)
	+0.000000001*(stop.tv_nsec-start.tv_nsec);
    for (j = 0; j < list_size; j++) {
        true_sdev += pow(list[j]-true_mean_final,2)/(list_size-1);
    }
    true_sdev_final = sqrt(true_sdev);
    // Check answer
    if (abs(true_mean_final - global_mean) > 0.0001) {
	printf("Houston, we have a problem!\n"); 
    }
    if (abs(true_sdev_final - global_sdev) > 100000000) {
	printf("Houston, we have a problem!\n"); 
    }
    // Print time taken
    printf("Threads = %d, time (sec) = %8.4f\n", 
	    num_threads, total_time);
	printf("mean = %8.4Lf, sdev = %8.4Lf\n", 
	    global_mean, global_sdev);
    printf("true_mean_final = %8.4Lf, true_sdev_final = %8.4Lf\n", 
	    true_mean_final, true_sdev_final);
}


