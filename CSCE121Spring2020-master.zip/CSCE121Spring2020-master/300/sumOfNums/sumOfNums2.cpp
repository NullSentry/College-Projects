#include <iostream>

using namespace std;

int main () {
  int num = 0;
  int sum = 0;
  for (int i=0; i<5; ++i) { // ++i = i = i + 1;
    cin >> num;
    sum += num; // sum = sum + num;
  }
  cout << "Sum is " << sum << endl;
  return 0;
}