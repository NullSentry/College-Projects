#include <iostream>

int main () {
  int num = 0;
  int sum = 0;
  for (int i=0; i<5; ++i) { // ++i = i = i + 1;
    std::cin >> num;
    sum += num; // sum = sum + num;
  }
  std::cout << "Sum is " << sum << std::endl;
}