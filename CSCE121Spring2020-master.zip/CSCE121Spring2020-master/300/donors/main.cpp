#include <string>
#include "functions.h"

using namespace std;

int main() {
  const int maxCapacity = 10;
  double donations[maxCapacity];
  int numdonors[maxCapacity];
  string names[maxCapacity];
  int size = loadArrays("donors.txt", donations, numdonors, names, maxCapacity);
  printArrays(donations, numdonors, names, size, donations[max(donations,size)], 0);
}