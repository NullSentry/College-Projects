#include <iostream>

using std::cout, std::endl;

int countNum(int nums[], int num, int size) {
  int count = 0;
  for (int i=0; i<size; ++i) {
    if (nums[i] == num) {
      count ++;
    }
  }
  return count;
}

int main() {
  int nums[] {1, 2, 3, 4, 5, 5, 4, 7};
  int size = 8;
  
  for (int i=0; i<7; ++i) {
    int count = countNum(nums, nums[i], size);
    cout << nums[i] << " appears " << count << " times" << endl;
  }
}