#include <iostream>

using namespace std;

int main() {
  int num = 0;
  int sum = 0;
  cout << "Enter number: ";
  cin >> num;
  cout << "Sum of ";
  // make it happen
  while (num > 0) {
    int digit = 0;
    digit = num % 10;
    num = num / 10;
    sum += digit; // sum = sum + digit;
    cout << digit;
    if (num != 0)
      cout << " + ";
  }
  cout << " = " << sum << endl;
}