#include <iostream>
#include <string>

using namespace std;

int main() {
  string name { "Michael"} ;
  cout << name << endl;
  name += " Moore";
  cout << name << endl;
  cout << name.length() << endl;
  cout << name.at(name.length()/2) << endl;
}