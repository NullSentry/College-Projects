#include <iostream>

using namespace std;

int main() {
  string s = "hi";
  try {
    cout << s.at(7);
  }
  catch (std::out_of_range exc) {
    cout << exc.what() << endl;
  }
}