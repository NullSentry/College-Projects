#include <iostream>
#include <limits>

using namespace std;

int getValueInRange(istream& is, string prompt, int min, int max) {
  int num = 5;
  cout << prompt << endl;
  do {
    if (!is.good()) {
      is.clear(); // resets stream state to good
      is.ignore(numeric_limits<streamsize>::max(), '\n'); // clean out the buffer
    }
    is >> num;
  } while (!is.good() || num < min || num > max);
  return num;
}

int main() {
  int num = getValueInRange(cin, "Enter value from 2 to 7: ", 2, 7);
  cout << "num: " << num << endl;
}