#include <iostream>

using namespace std;

int main() {
  int num = 1;
  int cnt = 0;
  while (num != 0) {
    if ((num % 2) == 0) {
      cnt++; // cnt = cnt + 1; // initialized to odd value so won't count initialized value
    }
    cin >> num; 
  }
  cout << cnt << " even numbers" << endl;
}
