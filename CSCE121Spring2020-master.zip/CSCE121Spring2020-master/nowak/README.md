# Notes from the substitute, Michael Nowak (Jan-29 and Jan-31)
