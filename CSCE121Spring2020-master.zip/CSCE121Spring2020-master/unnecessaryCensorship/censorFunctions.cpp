#include <iostream>
#include <string>
#include <fstream>
#include "censorFunctions.h"

using namespace std;

int loadWords(string words[], ifstream& inFile, int maxCapacity) {
  cout << "start loadWords" << endl;
  int index = 0;
  string word;
  while (infile >> word && index < maxCapacity) {
    words[index] = word;
    index++;
  }
  return index;
}

void printStrings(string[] strings, int size) {
  cout << "start printStrings" << endl;
  for (int i=0; i<size; ++i) {
    cout << strings[i] << endl;
  }
}