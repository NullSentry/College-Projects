#ifndef CENSORFUNCTIONS_H
#define CENSORFUNCTIONS_H

#include <string>
#include <fstream>

// cannot use "using namespace" in header files
//  so you have to use fully qualified names, e.g. std:: string and std::cout

int loadWords(std::string words[], std::ifstream& inFile, int maxCapacity);
void printStrings(std::string[], int);

#endif