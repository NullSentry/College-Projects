#include <iostream>

using namespace std;

int main() {
	char character = '0';
	do {
		cin >> character;
	} while (isalnum(character) == true);
	cout << "Non alphanumeric: '" << character << "'" << endl; 
}