#include<iostream>

using namespace std; // so you don't have to do std:: all the time

int main() {
  short num = 1;
  while (num > 0) {
    cout << num << " ";
    if (num % 9 == 0) {
      cout << endl;
    }
    num++;
  }
  cout << endl;
  cout << "final value: " << num << endl;
}