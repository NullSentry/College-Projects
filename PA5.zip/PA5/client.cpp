#include "common.h"
#include "TCPreqchannel.h"
#include "BoundedBuffer.h"
#include "HistogramCollection.h"
#include <sys/wait.h>
#include <thread>
using namespace std;

struct Response{
	int pno;
	double ecg;
};

void patient_thread_function(int n, int pno, BoundedBuffer* request_buffer){
	DataRequest d(pno, 0.0,1);
    for(int i = 0; i < n; i++){
		vector<char> data((char*) &d, (char*) &d + sizeof(d));
        request_buffer->push(data);
        d.seconds += 0.004;
    }
    /*
		Functionality of the patient threads	
    */
}

void file_thread_function(string filename, int m, TCPRequestChannel* chan, BoundedBuffer* request_buffer){
	FileRequest fm (0,0);
	int len = sizeof (FileRequest) + filename.size()+1;
	char buf2 [len];
	memcpy (buf2, &fm, sizeof (FileRequest));
	strcpy (buf2 + sizeof (FileRequest), filename.c_str());
	chan->cwrite (buf2, len);  
	__int64_t filelen;
	chan->cread (&filelen, sizeof(__int64_t));
	__int64_t rem = filelen;
	FileRequest* f = (FileRequest*) buf2;
	char recvbuf [m];
	while (rem > 0){
		f->length = min(rem, (__int64_t)m);
		vector<char> data((char*) buf2, (char*) buf2 + len);
		request_buffer->push(data);
		rem -= f->length;
		f->offset += f->length;
	}
	
	/*
		Functionality of the filename thread
		Reuse of PA3 solution	
	*/
}

void worker_thread_function(BoundedBuffer* request_buffer, TCPRequestChannel* chan, BoundedBuffer* response_buffer, int m){
	char response[m];
	while(true){
		vector<char> req = request_buffer->pop();
		char* request = req.data();
		chan->cwrite(request, req.size());
		Request* data = (Request*)request;
		if (data->getType() == DATA_REQ_TYPE){
			int pno = ((DataRequest*)data)->person;
			double ecg = 0;
			chan->cread(&ecg, sizeof(double));
			Response r{pno, ecg};
			vector<char> resp((char*) &r, (char*) &r + sizeof(r));
			response_buffer->push(resp);
		}else if(data->getType() == FILE_REQ_TYPE){
			chan->cread(response,sizeof(response));
			FileRequest* fr = (FileRequest*)request;
            string fname = (char*)(fr+1);
			fname = "received/" + fname;
			FILE* fp = fopen(fname.c_str(),"r+");
			fseek(fp, fr->offset, SEEK_SET);
			fwrite(response,1,fr->length, fp);
			fclose(fp);
		}else if(data->getType() == QUIT_REQ_TYPE){
			break;
		}
	}
	/*
		Functionality of the worker threads	
    */
}
void histogram_thread_function (BoundedBuffer* response_buffer, HistogramCollection* hc){
    while(true){
		vector<char> response = response_buffer->pop();
		Response* r = (Response*)response.data();
		if (r->pno == -1){
			break;
		}
		hc->update(r->pno, r->ecg);
	}
	/*
		Functionality of the histogram threads	
    */
}

int main(int argc, char *argv[]){
	int opt = -1;
	int p = 15;
	double t = 0.0;
	int e = 1;
	int n = 15000;
    int w = 500;
	int h = 15;
	int m = MAX_MESSAGE;
	string filename = "";
	string host = "127.0.0.1";
	string port = "8551";
	int b = 1024;
    while((opt = getopt(argc,argv,"m:n:b:w:p:f:h:r:"))!=-1)
    {
        switch (opt)
        {
            case 'm':
                m = atoi(optarg);
                break;
            case 'n':
                n = atoi(optarg);
                break;
            case 'b':
                b = atoi(optarg);
                break;
            case 'w':
                w = atoi(optarg);
                break;
			case 'p':
                p = atoi(optarg);
                break;
            case 'f':
                filename = optarg;
                break;
			case 'h':
                host = optarg;
                break;
			case 'r':
                port = optarg;
                break;
        }
    }
	BoundedBuffer request_buffer(b);
	BoundedBuffer response_buffer(b);
	HistogramCollection hc;
	TCPRequestChannel* wchans [w];
	cerr << "Number of Channels: " << w << endl;
	for(int i = 0; i < w;i++){
	    /*Request nc(NEWCHAN_REQ_TYPE);
		chan.cwrite(&nc, sizeof(nc));
		char chanName [1024];
		chan.cread(chanName, sizeof(chanName));
		cerr << "New Channel Name: " << chanName << endl;*/
		wchans[i] = new TCPRequestChannel (host.c_str(),port.c_str());
    }
	for (int i = 0; i < p; i++){
		Histogram* h = new Histogram(10,-2.0, 2.0);
		hc.add(h);
	}
	struct timeval start, end;
    gettimeofday (&start, 0);
    /* Initalize threads here */
	thread worker [w];
	thread patient [p];
	thread histo[h];
	thread filethread;
	/* Start nonfile threads here */
	for (int i = 1; i <= w; i++){
		worker[i-1] = thread(worker_thread_function, &request_buffer, wchans[i-1], &response_buffer, m);
	}
	if (filename.empty()){
		for (int i = 1; i <= p; i++){
			patient[i-1] = thread(patient_thread_function, n, i, &request_buffer);
		}
		for (int i = 1; i <= h; i++){
			histo[i-1] = thread(histogram_thread_function, &response_buffer, &hc);
		}
		/* Join patient threads here */
		for(int i = 0; i < p;i++){
				patient[i].join();
		}	
	}else{
		//cout << "TEST" << endl;
		/* Start file threads here */
		TCPRequestChannel chan (host.c_str(),port.c_str());
		TCPRequestChannel* chanptr = &chan;
		fopen(("./received/"+filename).c_str(),"w");
		filethread = thread(file_thread_function, filename, m, &chan, &request_buffer);
		/* Join file threads here */
		filethread.join();
	}
	/* Join remaining threads here */
	/* Add exit conditions to buffers */
	Request wq (QUIT_REQ_TYPE);
	vector<char> quit((char*) &wq, (char*) &wq + sizeof(wq));
	for(int i = 0; i < w;i++){
			request_buffer.push(quit);
	}
	for(int i = 0; i < w;i++){
		worker[i].join();
	}
	if (filename.empty()){
		Response rq {-1, 0.0};
		vector<char> hquit((char*) &rq, (char*) &rq + sizeof(rq));
		for(int i = 0; i < h;i++){   
				response_buffer.push(hquit);
		}
		for(int i = 0; i < h;i++){
			histo[i].join();
		}
	}
    gettimeofday (&end, 0);
    // print the results and time difference
	if(filename.empty())
		hc.print ();
    int secs = (end.tv_sec * 1e6 + end.tv_usec - start.tv_sec * 1e6 - start.tv_usec)/(int) 1e6;
    int usecs = (int)(end.tv_sec * 1e6 + end.tv_usec - start.tv_sec * 1e6 - start.tv_usec)%((int) 1e6);
    cout << "Took " << secs << " seconds and " << usecs << " micro seconds" << endl;
	
	// closing the channel    
    /*Request q (QUIT_REQ_TYPE);
    chan.cwrite (&q, sizeof (Request));*/
	for (int i = 0; i < w; i++){
		delete wchans[i];
	}
	// client waiting for the server process, which is the child, to terminate
	wait(0);
	cout << "Client process exited" << endl;

}
