import React from "react";
import LandingSection from "../LandingSection";

const Landing = (props) => {
  return (
    <div>
      <LandingSection />
    </div>
  );
};

export default Landing;
