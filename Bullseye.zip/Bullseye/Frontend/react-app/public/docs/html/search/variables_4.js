var searchData=
[
  ['g_0',['g',['../classmap__search_1_1_node.html#ae66f69218f2862e401c3951d1a3df25d',1,'map_search::Node']]]
];
