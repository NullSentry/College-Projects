var searchData=
[
  ['parent_0',['parent',['../classmap__search_1_1_node.html#af048aad99a52bebf8077b59a14fc49cd',1,'map_search::Node']]],
  ['perpendicular_5fdistance_1',['perpendicular_distance',['../namespacemap__search.html#abd7c8fb19514081a6edf18c0622f9604',1,'map_search']]]
];
