var searchData=
[
  ['parent_0',['parent',['../classmap__search_1_1_node.html#af048aad99a52bebf8077b59a14fc49cd',1,'map_search::Node']]]
];
