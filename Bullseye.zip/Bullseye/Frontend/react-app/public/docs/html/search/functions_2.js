var searchData=
[
  ['create_5fmap_0',['create_map',['../namespacemap__create.html#a114131884c09f4c06b99bfeb2c7e70fa',1,'map_create']]]
];
