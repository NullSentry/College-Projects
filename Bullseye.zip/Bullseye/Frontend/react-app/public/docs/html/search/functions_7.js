var searchData=
[
  ['perpendicular_5fdistance_0',['perpendicular_distance',['../namespacemap__search.html#abd7c8fb19514081a6edf18c0622f9604',1,'map_search']]]
];
