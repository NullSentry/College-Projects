var searchData=
[
  ['douglas_5fpeucker_0',['douglas_peucker',['../namespacemap__search.html#a6304b78771ac23b58b129157380d9a4c',1,'map_search']]]
];
