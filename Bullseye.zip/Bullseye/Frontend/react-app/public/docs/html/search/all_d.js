var searchData=
[
  ['x_0',['x',['../classmap__search_1_1_node.html#a4748ba62715f5ec68ce473967e9d2755',1,'map_search::Node']]]
];
