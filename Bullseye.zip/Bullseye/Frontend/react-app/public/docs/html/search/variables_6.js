var searchData=
[
  ['matrix_0',['matrix',['../classmap__search_1_1_node.html#a3d35a82c9bbd1b1530d1ff7f61ca4611',1,'map_search::Node']]]
];
