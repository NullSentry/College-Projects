var map__create_8py =
[
    [ "create_map", "map__create_8py.html#a114131884c09f4c06b99bfeb2c7e70fa", null ],
    [ "remove_blobs", "map__create_8py.html#ae8b3e3e4472907493893fa09e616beb8", null ],
    [ "C", "map__create_8py.html#a8523dfee96e8844fad51488f49a7ddce", null ]
];