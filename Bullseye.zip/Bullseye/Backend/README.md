# Backend

>running backend:
* using docker: `poetry run start`
* Manual run:
* * `poetry shell`
* * `poetry run uvicorn bullseye_backend.main:app --reload`