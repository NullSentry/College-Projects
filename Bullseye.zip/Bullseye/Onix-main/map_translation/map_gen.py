import os, numpy as np
from svgpathtools import svg2paths
import cv2

map_file = open('test_data.txt')
entrance_loc, aisle_locs = (0, 0), []

# parse contents found inside '<g id="content">' to extract useful data from online store map
wall_shapes, reg_shapes, aisle_shapes, aisle_names = False, False, False, False
for line in map_file:
    if 'Wall-Shapes' in line:
        wall_shapes, reg_shapes, aisle_shapes, aisle_names = True, False, False, False

        wall_shapes_file = open('wall_shapes.txt', 'a')
        wall_shapes_file.write("<g>\n")
        wall_shapes_file.close()
    elif 'Register-Shapes' in line:
        wall_shapes, reg_shapes, aisle_shapes, aisle_names = False, True, False, False

        reg_shapes_file = open('reg_shapes.txt', 'a')
        reg_shapes_file.write("<g>\n")
        reg_shapes_file.close()
    elif 'Aisle-Shapes' in line:
        wall_shapes, reg_shapes, aisle_shapes, aisle_names = False, False, True, False

        aisle_shapes_file = open('aisle_shapes.txt', 'a')
        aisle_shapes_file.write("<g>\n")
        aisle_shapes_file.close()
    elif 'Aisle-Names' in line:
        wall_shapes, reg_shapes, aisle_shapes, aisle_names = False, False, False, True
    elif '</g>' in line:
        if wall_shapes:
            wall_shapes_file = open('wall_shapes.txt', 'a')
            wall_shapes_file.write("</g>\n")
            wall_shapes_file.close()
        elif reg_shapes:
            reg_shapes_file = open('reg_shapes.txt', 'a')
            reg_shapes_file.write("</g>\n")
            reg_shapes_file.close()
        elif aisle_shapes:
            aisle_shapes_file = open('aisle_shapes.txt', 'a')
            aisle_shapes_file.write("</g>\n")
            aisle_shapes_file.close()

        wall_shapes, reg_shapes, aisle_shapes, aisle_names = False, False, False, False
    else:
        # process data here
        # create files for paths of wall_shapes, reg_shapes, and aisle_shapes
        # don't forget to log entrance loc (and maybe restrooms, guest services, Starbucks, pharmacy, etc. in the future)
        if wall_shapes:
            # data stored in separate file for 'svg2paths'
            wall_shapes_file = open('wall_shapes.txt', 'a')
            wall_shapes_file.write(line)
            wall_shapes_file.close()
        elif reg_shapes:
            # data stored in separate file for 'svg2paths'
            reg_shapes_file = open('reg_shapes.txt', 'a')
            reg_shapes_file.write(line)
            reg_shapes_file.close()
        elif aisle_shapes:
            # data stored in separate file for 'svg2paths'
            aisle_shapes_file = open('aisle_shapes.txt', 'a')
            aisle_shapes_file.write(line)
            aisle_shapes_file.close()
        elif aisle_names:
            # get (x,y) locs of aisle names
            info = line.split(" ")[7: 9]
            x = int(float(info[0][3:-1]) * 100)
            y = int(float(info[1][3:-1]) * 100)
            aisle_locs.append((x, y))
        elif 'entrance' in line:
            # get (x,y) loc of entrance text
            info = line.split(" ")[-3:-1]
            x = int(float(info[0][3:-1]) * 100)
            y = int(float(info[1][3:-1]) * 100)
            entrance_loc = (x, y)


# get path data associated with all relevant store aspects
wall_paths, wall_attributes = svg2paths('wall_shapes.txt')
reg_paths, reg_attributes = svg2paths('reg_shapes.txt')
aisle_paths, aisle_attributes = svg2paths('aisle_shapes.txt')

# get bounds of all relevant paths
wall_bounds_init, reg_bounds_init, aisle_bounds_init = [path.bbox() for path in wall_paths], [path.bbox() for path in reg_paths], [path.bbox() for path in aisle_paths]
wall_bounds, reg_bounds, aisle_bounds = [], [], []

# scale up the data so it can be represented in our matrix
for bound in wall_bounds_init:
    wall_bounds.append((int(bound[0]*100), int(bound[1]*100), int(bound[2]*100), int(bound[3]*100)))

# store upper/lower/left/right bounds of map so we can use these as offsets in our matrix representation
# initialize matrix representation with '.'s, which represent places on the map that are traversable
map_xmin, map_xmax, map_ymin, map_ymax = wall_bounds[0]
map_data = np.full((map_ymax - map_ymin, map_xmax - map_xmin), 0, dtype=float)

# finish scaling up the data so it can be represented in our matrix
for bound in reg_bounds_init:
    reg_bounds.append((int(bound[0]*100) - map_xmin, int(bound[1]*100) - map_xmin, int(bound[2]*100) - map_ymin, int(bound[3]*100) - map_ymin))

for bound in aisle_bounds_init:
    aisle_bounds.append((int(bound[0]*100) - map_xmin, int(bound[1]*100) - map_xmin, int(bound[2]*100) - map_ymin, int(bound[3]*100) - map_ymin))


# create blocks/boundaries that represent areas that aren't traversable
all_bounds, boundaries = reg_bounds + aisle_bounds, []
for bound in all_bounds:
    xmin, xmax, ymin, ymax = bound[0], bound[1], bound[2], bound[3]
    boundaries.append(np.full((ymax - ymin, xmax - xmin), 1, dtype=float))

# add blocks/boundaries to map
for i in range(len(boundaries)):
    bound, boundary = all_bounds[i], boundaries[i]
    xmin, xmax, ymin, ymax = bound[0], bound[1], bound[2], bound[3]
    map_data[ymin: ymax, xmin: xmax] = boundary

# clean up intermediate files
os.remove('wall_shapes.txt')
os.remove('reg_shapes.txt')
os.remove('aisle_shapes.txt')

y,x = map_data.shape
map_data = cv2.resize(map_data, dsize=(x // 30, y // 30), interpolation=cv2.INTER_CUBIC)

# write results of map translation to output file
open('test_res.txt', 'a')
np.savetxt("test_res.txt", map_data, newline="\n", fmt='%i')