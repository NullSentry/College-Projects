#include "BuddyAllocator.h"
#include <iostream>
#include <math.h>
using namespace std;

LinkedList::LinkedList(){
	listLength = 0;
}

void LinkedList::deleteList(){
	BlockHeader* curr = head;
    BlockHeader* next = nullptr;
 
    while (curr != nullptr)
    {
        next = curr->next;
        free(curr);
        curr = next;
    }
    head = nullptr;
}
int LinkedList::getListLength(){
	return listLength;
}
BlockHeader* LinkedList::getHead(){
	return head;
}

void LinkedList::insert(BlockHeader* b){
	if( !head ){
		b->next = nullptr;
	}else{
		b->next  = head;
	}
	head = b;
	b->isFree = true;
	listLength += 1;
}

void LinkedList::remove(BlockHeader* b){
	BlockHeader* temp = head;
	if(temp == b){
		if(temp->next != nullptr){
			head = temp->next;
			listLength -= 1;
			b->isFree = false;
		}else{
			head = nullptr;
			listLength = 0;
		}
	}else{
		for(int i = 1; i < listLength; i++){
			if(temp->next == b){
				if(temp->next->next != nullptr){
					temp->next = temp->next->next;
					listLength -= 1;
					b-> isFree = false;
				}
				else{
					temp->next = nullptr;
					listLength -= 1;
					b->isFree = false;
				}
			}
			else {
				temp = temp->next;
			}
		}
	}
}

BuddyAllocator::BuddyAllocator (int _basic_block_size, int _total_memory_length){
	int i = 1;
	while((_basic_block_size * i) < _total_memory_length){
		i = i*2;
	}
	total_memory_size = _basic_block_size * i;
	front = new BlockHeader [int(total_memory_size)];
	BlockHeader* blheader = (BlockHeader*) front;
	blheader->isFree = true;
	blheader->block_size = total_memory_size;
	blheader->next = nullptr;
	basic_block_size = _basic_block_size;
	l = int(log2(ceil(total_memory_size/basic_block_size))) + 1;
	LinkedList* temp = new LinkedList[l];
	for (int i = 0; i < l; i++){
		FreeList.push_back(temp[i]);
	}
	delete[] temp;
	FreeList[this->nextFreeBlock(total_memory_size)].insert(blheader);
}

BuddyAllocator::~BuddyAllocator (){
	delete[] front;
	FreeList.clear();
}

int BuddyAllocator::nextFreeBlock(int size){
	return l - ( (int(log2(total_memory_size/size)) + 1) );
}

BlockHeader* BuddyAllocator::getbuddy (BlockHeader* adr){
	int blockSize = adr->block_size;
	void* buddy = ((adr - front) ^ blockSize) + front;
	return ((adr - front) ^ blockSize) + front;
}

bool BuddyAllocator::arebuddies (BlockHeader* b1, BlockHeader* b2){
	BlockHeader* bh1 = (BlockHeader*) b1;
  	BlockHeader* bh2 = (BlockHeader*) b2;
	return bh2->isFree && bh1->block_size == bh2->block_size;
}

BlockHeader* BuddyAllocator::merge (BlockHeader* block1, BlockHeader* block2){
	BlockHeader* leftBuddy;
	BlockHeader* rightBuddy;
	if(block1 > block2 ){
		leftBuddy = block2;
		rightBuddy = block1;
	}
	else if ( block1 < block2){
		leftBuddy = block1;
		rightBuddy = block2;
	}
	int originalSize = leftBuddy->block_size;
	int newSize = originalSize * 2;

	FreeList[this->nextFreeBlock(originalSize)].remove(leftBuddy);
	FreeList[this->nextFreeBlock(originalSize)].remove(rightBuddy);
	FreeList[this->nextFreeBlock(newSize)].insert(leftBuddy);

	BlockHeader* mergeBlock = leftBuddy;
	mergeBlock->block_size = newSize;
	return mergeBlock;
}

BlockHeader* BuddyAllocator::split (BlockHeader* block){
	BlockHeader* leftBuddy = block;
	int originalSize = leftBuddy->block_size;
	//remove original block
	FreeList[this->nextFreeBlock(originalSize)].remove(leftBuddy);
	int splitSize = originalSize / 2;
	BlockHeader* rightBuddy = block + splitSize;
	leftBuddy->block_size = splitSize;
	leftBuddy->next = nullptr;
	rightBuddy->block_size = splitSize;
	rightBuddy->next = nullptr;
	//insert left block and right block of 1/2 size
	FreeList[this->nextFreeBlock(splitSize)].insert(leftBuddy);
	FreeList[this->nextFreeBlock(splitSize)].insert(rightBuddy);
	return leftBuddy;
}

//returns the address of the allocated block
char* BuddyAllocator::alloc(int _length) {
	int i = 0;
	int j = 1;
	// If the amount asked for exceeds the amount avalible, return nothing
	if(_length > total_memory_size - sizeof(BlockHeader)) {
		throw std::out_of_range("Exception occurred: Access attempt out of bounds");
		return nullptr;
	}
	// Gets the nearest power of 2
	while (( basic_block_size * j) - sizeof(BlockHeader) < _length){
		j = j * 2;
		i = i + 1;
	}
	// Gets largest block from power of 2 calculated
	int largestBlock = basic_block_size * j;
	if(FreeList[i].getListLength() > 0){
		BlockHeader* block = FreeList[i].getHead();
		block->isFree = false;
		block->next = nullptr;
		FreeList[i].remove(block);
		char* blockReturn = (char*) block;
		return (char*) (blockReturn + sizeof(BlockHeader));
	}
	else{
		BlockHeader* splitBlock;
		while (FreeList[i].getListLength() == 0){
			i++;
			if (i >= l){
				return nullptr;
			}
		}
		int currentBlockSize = FreeList[i].getHead()->block_size;
		while(largestBlock != currentBlockSize){
			BlockHeader* block = (BlockHeader*) FreeList[nextFreeBlock(currentBlockSize)].getHead();
			splitBlock = this->split(block);
			block = splitBlock;
			currentBlockSize = currentBlockSize / 2;
		}
		FreeList[nextFreeBlock(currentBlockSize)].remove((BlockHeader*) splitBlock);
		BlockHeader* splitBlockHeader = (BlockHeader*) splitBlock;
		char* splitBlock2 = (char*) splitBlock;
		return (splitBlock2 + sizeof(BlockHeader) );
	}
  // return new char [_length];
  return nullptr;
}

//return memory to the system that was retrieved in alloc()
int BuddyAllocator::free(char* _a) {
	BlockHeader* bh = (BlockHeader*)(_a - sizeof(BlockHeader));
	FreeList[freeListPosition(bh->block_size)].insert(bh);
	bool merging = true;
	int newSize = bh->block_size;
	while (merging){
		BlockHeader* buddy = getbuddy(bh);
		BlockHeader* buddy_header = (BlockHeader*) buddy;
		if (arebuddies(bh, buddy)){
			bh = merge(bh, buddy);
		}
		else merging = false;
	}
	return 0;
}

int BuddyAllocator::getListLength(){
	// Simple Getter
	return l;
}

vector<LinkedList> BuddyAllocator::getList(){
	// Simple Getter
	return FreeList;
}


void BuddyAllocator::printlist (){
  cout << "Printing the Freelist in the format \"[index] (block size) : # of blocks\"" << endl;
  for (int i=0; i<l; i++){
    cout << "[" << i <<"] (" << ((1<<i) * basic_block_size) << ") : ";  // block size at index should always be 2^i * bbs
    int count = 0;
    BlockHeader* b = FreeList[i].getHead();
    // go through the list from head to tail and count
    while (b){
      count ++;
      // block size at index should always be 2^i * bbs
      // checking to make sure that the block is not out of place
      if (b->block_size != (1<<i) * basic_block_size){
        cerr << "ERROR:: Block is in a wrong list" << endl;
        exit (-1);
      }
      b = b->next;
    }
    cout << count << endl;

  }
}

