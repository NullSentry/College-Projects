#include "Ackerman.h"
#include "BuddyAllocator.h"
#include <unistd.h>

void easytest(BuddyAllocator* ba){
  // be creative here
  // know what to expect after every allocation/deallocation cycle

  // here are a few examples
  ba->printlist();
  // allocating a byte
  char * mem = ba->alloc (1);
  // now print again, how should the list look now
  ba->printlist ();

  ba->free (mem); // give back the memory you just allocated

  ba->printlist(); // shouldn't the list now look like as in the beginning

}

int main(int argc, char ** argv) {
  int basic_block_size = 128, memory_length = 128 * 1024 * 1024;
  int x;
  try{
      while((x = getopt(argc, argv, "b:s:")) != -1){
        switch(x) {
            //sets size of basic memory block
            case 'b':
              basic_block_size = atoi(optarg);
              if (!basic_block_size){cout << "Error: Invalid input given for Block Size.\nFormat: ./[filename] -b [blocksize] -s [memsize] " << endl; exit(1);}
              std::cout << "Basic Block Size Set to:" << basic_block_size << std::endl;
              break;

            //sets size of total allowed memory
            case 's':
              memory_length = atoi(optarg);
              if (!memory_length){cout << "Error: Invalid input given for Memory Length.\nFormat: ./[filename] -b [blocksize] -s [memsize] " << endl; exit(1);}
              std::cout << "Memory Length Set to:" << memory_length << std::endl;
              break;
            case '?':
              std::cout << "Error in Command Arguments\nFormat: ./[filename] -b [blocksize] -s [memsize] " << std::endl;
              exit(1);
          }
      }
    }catch (...){
      std::cout << "An error was encountered" << std::endl;
    }
    try{
      // create memory manager
      BuddyAllocator * allocator = new BuddyAllocator(basic_block_size, memory_length);

      // the following won't print anything until you start using FreeList and replace the "new" with your own implementation
      easytest (allocator);

      
      // stress-test the memory manager, do this only after you are done with small test cases
      Ackerman* am = new Ackerman ();
      am->test(allocator); // this is the full-fledged test. 
      
      // destroy memory manager
      delete allocator;
      delete am;
    }catch(...){
      std::cout << "An error was encountered" << std::endl;
    }
}
