/*
Zachary Knight Lewis
CSCE 312-501
*/
#include <fstream>
#include <iostream>
#include <vector>
#include <map>
#include <sstream>
#include <algorithm>
using namespace std;

struct Syntax_Error : public exception {
    const char * what () const throw () {
            return "ERROR: expression expected";
    }
};

struct Semi_Error : public exception {
    const char * what () const throw () {
            return "ERROR: end of line expected but semicolon is found";
    }
};

map<string, string> comp_OG = {
    {"0", "0101010"},
    {"1", "0111111"},
    {"-1", "0111010"},
    {"D", "0001100"},
    {"A", "0110000"},
    {"!D", "0001101"},
    {"!A", "0110001"},
    {"-D", "0001111"},
    {"-A", "0110011"},
    {"D+1", "0011111"},
    {"1+D", "0011111"},
    {"A+1", "0110111"},
    {"1+A", "0110111"},
    {"D-1", "0001110"},
    {"A-1", "0110010"},
    {"D+A", "0000010"},
    {"A+D", "0000010"},
    {"D-A", "0010011"},
    {"A-D", "0000111"},
    {"D&A", "0000000"},
    {"A&D", "0000000"},
    {"D|A", "0010101"},
    {"A|D", "0010101"},
    {"M", "1110000"},
    {"!M", "1110001"},
    {"-M", "1110011"},
    {"M+1", "1110111"},
    {"1+M", "1110111"},
    {"M-1", "1110010"},
    {"D+M", "1000010"},
    {"M+D", "1000010"},
    {"D-M", "1010011"},
    {"M-D", "1000111"},
    {"D&M", "1000000"},
    {"M&D", "1000000"},
    {"D|M", "1010101"},
    {"M|D", "1010101"}
};

map<string, string> dest_OG = {
    {"null", "000"},
    {"M", "001"},
    {"D", "010"},
    {"A", "100"},
    {"MD", "011"},
    {"AM", "101"},
    {"AD", "110"},
    {"AMD", "111"}
};

map<string, string> jump_OG = {
    {"null", "000"},
    {"JGT", "001"},
    {"JEQ", "010"},
    {"JGE", "011"},
    {"JLT", "100"},
    {"JNE", "101"},
    {"JLE", "110"},
    {"JMP", "111"}
};

map<string, int> table_OG = {
    {"R0", 0},
    {"R1", 1},
    {"R2", 2},
    {"R3", 3},
    {"R4", 4},
    {"R5", 5},
    {"R6", 6},
    {"R7", 7},
    {"R8", 8},
    {"R9", 9},
    {"R10", 10},
    {"R11", 11},
    {"R12", 12},
    {"R13", 13},
    {"R14", 14},
    {"R15", 15},
    {"SCREEN", 16384},
    {"KBD", 24576},
    {"SP", 0},
    {"LCL", 1},
    {"ARG", 2},
    {"THIS", 3},
    {"THAT", 4}
};

string toBinary(int deci){ // Converts an integer into a binary string
    if (deci > 32767){
        throw Syntax_Error();
    }
    if (deci < 0){
        throw Syntax_Error();
    }
    int binaryNum[16]; 
    string binary = "0000000000000000";
    string binary2;
    int i = 0; 
    while (deci > 0) { 
        binaryNum[i] = deci % 2; 
        deci = deci / 2; 
        i++; 
    } 
    size_t k = i;
    for (size_t j = 0; j < k; j++)
        binary2 += to_string(binaryNum[j]);
    for (int j = i - 1; j >= 0; j--)
       binary.at(binary.size()-1-j) = binary2.at(j); 
   return binary;
} 

vector<string> readLines(){ // Reads from the .asm file and converts it into text, not including any spaces or comments
    string rec;
    vector<string> vec;
    // Get the input and output file names, and provide usage instructions
    //  if too few or too many arguments are provided.    
    // Load the records from the file into the vector,
    cin >> ws;
    bool star = false;
    bool comment = false;
    while (getline(cin, rec)) {
        if (rec.find("EOF") != string::npos){
            break;
        }
        comment = false;
        string cutString = rec;
        for (size_t i = 0; i < rec.size(); i++){
            if (rec.at(i) == '/'){
                if (rec.at(i+1) == '/') {
                    comment = true;
                    cutString = rec.substr(0, i);
                    break;
                }
                else if (rec.at(i+1) == '*') {
                    star = true;
                }else if (!(star) && !(comment)){
                    throw Syntax_Error();
                }
            }
            if (rec.at(i) == '*' && rec.at(i+1) == '/'){
                cutString = "";
                star = false;
            }
        }
        if (cutString.size() && !star){
            vec.push_back(cutString);
        }
        cin >> ws;
    }
    for (size_t i = 0; i < vec.size(); i++){
        string x = "";
        stringstream ss;
        ss << vec.at(i);
        vec.at(i) = "";
        while (ss >> x) { 
            vec.at(i) += x;
        }
		if (vec.at(i).at(0) ==';'){
			throw Semi_Error();
		}
        auto it = vec.at(i).find('(');
        auto it2 = vec.at(i).find(')');
        if (it != string::npos){
            if (it2 == string::npos){
            //    cout << "ERROR: expression expected" << endl;
                throw Syntax_Error();
            }
            string x = vec.at(i).substr(it+1,it2-1);
            //cout << x << endl;
            table_OG.insert(pair<string,int>(x,i));
            vec.erase(vec.begin()+i);
            i--;
        }else{
            if (it2 != string::npos){
               // cout << "ERROR: expression expected" << endl;
                throw Syntax_Error();
            }
        }
    }
    return vec;
}

string shred(string& line, string id, bool left){ // Shreds away the left or right side of a specific part of string and returns what was removed
    size_t found = line.find(id);
    string shredded = "X";
    if (found!=std::string::npos){
        if (left){
            shredded = line.substr(0,found);
            line = line.substr(found+1);
			if (shredded.size() == 0){
				throw Syntax_Error();
			}
        }else{
            shredded = line.substr(found+1);
            line = line.substr(0,found);
			if (shredded.size() == 0){
				throw Syntax_Error();
			}
        }
    }
    return shredded;
}

bool notNum(string line){ // Checks to make sure a string input is not a number
    if (isblank(line.at(line.size()-1)))
        line.pop_back();
    for (size_t i = 0; i < line.size(); i++){
        if (line.at(0) != '-' && !isdigit(line.at(0))){
            return true;
        }
        if (i && !isdigit(line.at(i))){
            return true;
        }
    }
    return false;
}


int main() {
    string binaryID;
    int tableID = 15;
    int iD;
    vector<string> vec;
    vector<pair<string, string>> vecTrans;
    map<string, string> comp = comp_OG;
    map<string, string> dest = dest_OG;
    map<string, string> jump = jump_OG;
    try{ // If an error is caught, the program is aborted
        vec = readLines(); // Reads file and stores it's no-comment/no-space text into a vector
        map<string, int> table = table_OG;
        // Print the records,
        for (auto line: vec) {
            if (isblank(line.at(line.size()-1)))
                line.pop_back();
            bool compT = false;
            bool jumpT = false;
            bool destT = false;
            bool aT = false;
            string binary = "";
            if (line.at(0) == '@'){
                line.erase(line.begin());
                for (size_t i = 0; i < line.size(); i++){
                    int j = i;
                    if (isblank(line.at(line.size()-j-1)))
                        line.pop_back();
                }
                if (notNum(line)){
                    if (table.find(line) != table.end()){
                        iD = table.at(line);
                        binaryID = toBinary(iD);
                    }else{ // Error for numbers outside 16-bit
                        tableID++;
                        iD = tableID;
                        table.insert(pair<string,int>(line,iD));
                        binaryID = toBinary(iD);
                    }
                }else{
                    binaryID = toBinary(stoi(line));
                }
                // @X -> 000...BinaryVal/TableVal
                aT = true;
            }else{
                // Dest
                string destiny = shred(line,"=", 1);
                if (destiny.size()){
                    if (isblank(destiny.at(destiny.size()-1)))
                        destiny.pop_back();
                    if (destiny.size() != 0){
                        if (dest.find(destiny) != dest.end())
                            destT = true;
                    }
                }
                // Jump
                string line_old = line;
                string landing = shred(line,";", 0);
                if (landing.size()){
                    if (isblank(landing.at(landing.size()-1)))
                        landing.pop_back();
                    if (landing.size() != 0){
                        if (jump.find(landing) != jump.end())
                            jumpT = true;
                    }
                }else if (line_old != line){
                    jumpT = true;
                }
                // Comp 
                string computed = line;
                if (comp.find(line) != comp.end())
                    compT = true;
                binary += "111";
                if (compT){binary += comp.at(line);}
                else{binary += "0000000";}
                if (destT){binary += dest.at(destiny);}
                else{binary += "000";}
                if (jumpT){binary += jump.at(landing);}
                else{binary += "000";}
                binaryID = binary;
            }
            if ((compT) || (aT)){
                cout << binaryID << endl;
            }else{
                //cout << "ERROR: expression expected" << endl;
                throw Syntax_Error();
            }
        }          
    }
    catch (exception& e){
		cout << e.what() << endl;
        return 0;
    }
    return 0;
}