/*
Zachary Knight Lewis
CSCE 312-501
*/
#include <fstream>
#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <sstream>

using namespace std;

struct Syntax_Error : public exception {
    const char * what () const throw () {
            return "Error: Invalid Syntax";
    }
};

map<string, string> comp_OG = {
    {"0", "0101010"},
    {"1", "0111111"},
    {"-1", "0111010"},
    {"D", "0001100"},
    {"A", "0110000"},
    {"!D", "0001101"},
    {"!A", "0110001"},
    {"-D", "0001111"},
    {"-A", "0110011"},
    {"D+1", "0011111"},
    {"1+D", "0011111"},
    {"A+1", "0110111"},
    {"1+A", "0110111"},
    {"D-1", "0001110"},
    {"A-1", "0110010"},
    {"D+A", "0000010"},
    {"A+D", "0000010"},
    {"D-A", "0010011"},
    {"A-D", "0000111"},
    {"D&A", "0000000"},
    {"A&D", "0000000"},
    {"D|A", "0010101"},
    {"A|D", "0010101"},
    {"M", "1110000"},
    {"!M", "1110001"},
    {"-M", "1110011"},
    {"M+1", "1110111"},
    {"1+M", "1110111"},
    {"M-1", "1110010"},
    {"D+M", "1000010"},
    {"M+D", "1000010"},
    {"D-M", "1010011"},
    {"M-D", "1000111"},
    {"D&M", "1000000"},
    {"M&D", "1000000"},
    {"D|M", "1010101"},
    {"M|D", "1010101"}
};

map<string, string> dest_OG = {
    {"M", "001"},
    {"D", "010"},
    {"A", "100"},
    {"MD", "011"},
    {"AM", "101"},
    {"AD", "110"},
    {"AMD", "111"}
};

map<string, string> jump_OG = {
    {"JGT", "001"},
    {"JEQ", "010"},
    {"JGE", "011"},
    {"JLT", "100"},
    {"JNE", "101"},
    {"JLE", "110"},
    {"JMP", "111"}
};

map<string, int> table_OG = {
    {"R0", 0},
    {"R1", 1},
    {"R2", 2},
    {"R3", 3},
    {"R4", 4},
    {"R5", 5},
    {"R6", 6},
    {"R7", 7},
    {"R8", 8},
    {"R9", 9},
    {"R10", 10},
    {"R11", 11},
    {"R12", 12},
    {"R13", 13},
    {"R14", 14},
    {"R15", 15},
    {"SCREEN", 16384},
    {"KBD", 24576},
    {"SP", 0},
    {"LCL", 1},
    {"ARG", 2},
    {"THIS", 3},
    {"THAT", 4}
};

string toBinary(int deci){ // Converts an integer into a binary string
    int binaryNum[16]; 
    string binary = "0000000000000000";
    string binary2;
    int i = 0; 
    while (deci > 0) { 
        binaryNum[i] = deci % 2; 
        deci = deci / 2; 
        i++; 
    } 
	size_t k = i;
    for (size_t j = 0; j < k; j++)
        binary2 += to_string(binaryNum[j]);
    for (int j = i - 1; j >= 0; j--)
       binary.at(binary.size()-1-j) = binary2.at(j); 
   return binary;
} 

vector<string> readLines(){ // Reads from the .asm file and converts it into text, not including any spaces or comments
    string rec;
    vector<string> vec;
    // Get the input and output file names, and provide usage instructions
    //  if too few or too many arguments are provided.    
    // Load the records from the file into the vector,
    cin >> ws;
    bool star = false;
    bool comment = false;
    while (getline(cin, rec)) {
        transform(rec.begin(), rec.end(),rec.begin(), ::toupper);
        if (rec.find("EOF") != string::npos)
            break;
        comment = false;
        string cutString = rec;
        for (size_t i = 0; i < rec.size(); i++){
            if (rec.at(i) == '/'){
                if (rec.at(i+1) == '/') {
                    comment = true;
                    cutString = rec.substr(0, i);
                    break;
                }
                else if (rec.at(i+1) == '*') {
                    star = true;
                }else if (!(star) && !(comment)){
                    throw Syntax_Error();
                }
            }
            if (rec.at(i) == '*' && rec.at(i+1) == '/'){
                cutString = "";
                star = false;
            }
        }
        if (cutString.size() && !star){
            vec.push_back(cutString);
        }
        cin >> ws;
    }
    for (size_t i = 0; i < vec.size(); i++){
        stringstream ss;
        ss << vec.at(i);
        ss >> ws;
        ss >> vec.at(i);
    }
    return vec;
}

string shred(string& line, string id, bool left){ // Shreds away the left or right side of a specific part of string and returns what was removed
    size_t found = line.find(id);
    string shredded = "X";
    if (found!=std::string::npos){
        if (left){
            shredded = line.substr(0,found);
            line = line.substr(found+1);
        }else{
            shredded = line.substr(found+1);
            line = line.substr(0,found);
        }
    }
    return shredded;
}

bool notNum(string line){ // Checks to make sure a string input is not a number
    if (isblank(line.at(line.size()-1)))
        line.pop_back();
    for (size_t i = 0; i < line.size(); i++){
        if (!isdigit(line.at(i))){
            return true;
        }
    }
    return false;
}

int main() {
    string binaryID;
    vector<string> vec;
    vector<string> vecTrans;
    map<string, string> comp = comp_OG;
    map<string, string> dest = dest_OG;
    map<string, string> jump = jump_OG;
    map<string, int> table = table_OG;
    // If an error is caught, the program is aborted
        vec = readLines(); // Reads file and stores it's no-comment/no-space text into a vector
        // Print the records,
        for (auto line: vec) {
            if (isblank(line.at(line.size()-1)))
                line.pop_back();
            bool compT = false;
            bool jumpT = false;
            bool destT = false;
            string binary = "";
            if (line.at(0) == '@'){
                line.erase(line.begin());
                binaryID = toBinary(stoi(line));
                vecTrans.push_back(binaryID);
                // @X -> 000...BinaryVal/TableVal
            }else{
                // Dest
                string destiny = shred(line,"=", 1);
                if (isblank(destiny.at(destiny.size()-1)))
                    destiny.pop_back();
                if (destiny.size() != 0){
                    if (dest.find(destiny) != dest.end())
                        destT = true;
                }
                // Jump
                string landing = shred(line,";", 0);
                if (isblank(landing.at(landing.size()-1)))
                    landing.pop_back();
                if (landing.size() != 0){
                    if (jump.find(landing) != jump.end())
                        jumpT = true;
                }
                // Comp 
                string computed = line;
                if (comp.find(line) != comp.end())
                    compT = true;
                binary += "111";
                if (compT){binary += comp.at(line);}
                else{binary += "0000000";}
                if (destT){binary += dest.at(destiny);}
                else{binary += "000";}
                if (jumpT){binary += jump.at(landing);}
                else{binary += "000";}
                binaryID = binary;
                vecTrans.push_back(binaryID);
            }
            cout << binaryID << endl;
        }
    return 0;
}