Code Summaries:

-Basic Assembler (basic.cpp):
--Takes an input from the user, the user will either copy and paste the entire assembly code,
or simply input the code line by line. 
--An inital scan to remove spaces happens.
--As this is the basic assembler, no inital scans for jumps happens.
--If the user inputs an @X, in which X is a positive integer, that integer gets translated into binary.
--The binary is in the format 0XXXXXXXXXXXXXXX, in which X can either be 0 or 1.
--If the number is > 32767 (meaning the binary value is 1XXXXXXXXXXXXXXX), an error is thrown.
--If the user inputs a value in the format of Dest = Comp ; JMP, Dest = Comp, or Comp.
--the program finds the values of Comp, Dest, and Jump from their tables and ouputs the desired binary in the
format 1XXXXXXXXXXXXXXX.
--If you get a case in which you have an equal sign or a semi-colon without a Dest or Jump, 
an error is thrown.

-Advanced Assembler (assembler.cpp):
--Takes an input from the user, the user will either copy and paste the entire assembly code,
or simply input the code line by line. 
--An inital scan to remove spaces happens.
--As this is the advanced assembler, the assembler also searches for declared variables in the format
(LOOP_NAME).
--If a (LOOP_NAME) is found, the line number in which it was found is saved, the line value is saved 
to the variable table, and the line from the assembly code is removed for the second scan.
--If the user inputs an @X, in which X is a positive integer, that integer gets translated into binary.
--The binary is in the format 0XXXXXXXXXXXXXXX, in which X can either be 0 or 1.
--If the user inputs an @X, in which X is a variable name from the variable table, the binary value 
from the table is applied in the format 0XXXXXXXXXXXXXXX.
--Otherwise, the first undefined variable is set to 16 in binary, the next undefined is 17, 18, ect.
--If the binary value is > 32767 (meaning the binary value is 1XXXXXXXXXXXXXXX), an error is thrown.
--If the user inputs a value in the format of Dest = Comp ; JMP, Dest = Comp, or Comp.
--the program finds the values of Comp, Dest, and Jump from their tables and ouputs the desired binary in the
format 1XXXXXXXXXXXXXXX. 
--If you get a case in which you have an equal sign or a semi-colon without a Dest or Jump, 
an error is thrown.

-Dessembler (dessembler.cpp):
--Takes an input from the user, the user will either copy and paste the entire binary code,
or simply input the code line by line. 
--An inital scan to remove spaces happens.
--If the binary is in the format 0XXXXXXXXXXXXXXX, in which X can either be 0 or 1, the code is 
translated into @X, in which X is a binary value from 0 to 32767. For example, 000000000000001
would translate to @1. 000000000000101 would translate to @5. 011111111111111 would translate
to @32767.
--If the binary is in the format 111XXXXXXXXXXXXX, in which X can either be 0 or 1, the code is 
translated into the format of  Dest = Comp ; JMP, Dest = Comp, or Comp.
--The program first finds the Dest values 111XXXXXXX[DDD]XXX, as they are on the lefthand side.
--If the dest values are all zero, nothing is added to the assembly line. 
--Otherwise, the matching dest value from the table is added along with an equal sign.
--The program then finds the Comp values 111[ACCCCCC]XXXXXX from the table, 
as comp is the next part of the string after dest. 
--If there are no matching values, an error is thrown.
--The program then finds the JMP values 111XXXXXXXXXX[JJJ] from the table.
--If the jmp values are all zero, nothing is added to the assembly line.
--Otherwise, a semicolon is added to the assembly line, along with the matching jmp value.