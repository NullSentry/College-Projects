/*
Zachary Knight Lewis
CSCE 312-501
*/
#include <fstream>
#include <iostream>
#include <vector>
#include <map>
#include <cmath>
#include <sstream>

using namespace std;

struct Syntax_Error : public exception {
    const char * what () const throw () {
            return "Error: Invalid Syntax";
    }
};

map<string, string> comp_OG = {
    {"1110101010", "0"},
    {"1110111111", "1"},
    {"1110111010", "-1"},
    {"1110001100", "D"},
    {"1110110000", "A"},
    {"1110001101", "!D"},
    {"1110110001", "!A"},
    {"1110001111", "-D"},
    {"1110110011", "-A"},
    {"1110011111", "D+1"},
    {"1110110111", "A+1"},
    {"1110001110", "D-1"},
    {"1110110010", "A-1"},
    {"1110000010", "D+A"},
    {"1110010011", "D-A"},
    {"1110000111", "A-D"},
    {"1110000000", "D&A"},
    {"1110010101", "D|A"},
    {"1111110000", "M"},
    {"1111110001", "!M"},
    {"1111110011", "-M"},
    {"1111110111", "M+1"},
    {"1111110010", "M-1"},
    {"1111000010", "D+M"},
    {"1111010011", "D-M"},
    {"1111000111", "M-D"},
    {"1111000000", "D&M"},
    {"1111010101", "D|M"}
};

map<string, string> dest_OG = {
    {"000", ""},
    {"001", "M"},
    {"010", "D"},
    {"100", "A"},
    {"011", "MD"},
    {"101", "AM"},
    {"110", "AD"},
    {"111", "AMD"}
};

map<string, string> jump_OG = {
    {"000", ""},
    {"001", "JGT"},
    {"010", "JEQ"},
    {"011", "JGE"},
    {"100", "JLT"},
    {"101", "JNE"},
    {"110", "JLE"},
    {"111", "JMP"}
};

string toDecimal(string binary){ // Converts an integer into a binary string
    int decimal=0;
    for (size_t i = 0; i < binary.size(); i++)
        if (binary.at(i) == '1')
            decimal+= (int)(pow(2, binary.size()-i-1));
   return to_string(decimal);
} 

vector<string> readLines(){ // Reads from the .asm file and converts it into text, not including any spaces or comments
    string rec;
    vector<string> vec;
    // Get the input and output file names, and provide usage instructions
    //  if too few or too many arguments are provided.    
    // Load the records from the file into the vector,
    cin >> ws;
    bool star = false;
    bool comment = false;
    while (getline(cin, rec)) {
        if (rec.find("EOF") != string::npos)
            break;
        comment = false;
        string cutString = rec;
        for (size_t i = 0; i < rec.size(); i++){
            if (rec.at(i) == '/'){
                if (rec.at(i+1) == '/') {
                    comment = true;
                    cutString = rec.substr(0, i);
                    break;
                }
                else if (rec.at(i+1) == '*') {
                    star = true;
                }else if (!(star) && !(comment)){
                    throw Syntax_Error();
                }
            }
            if (rec.at(i) == '*' && rec.at(i+1) == '/'){
                cutString = "";
                star = false;
            }
        }
        if (cutString.size() && !star){
            vec.push_back(cutString);
        }
        cin >> ws;
    }
    for (size_t i = 0; i < vec.size(); i++){
        stringstream ss;
        ss << vec.at(i);
        ss >> ws;
        ss >> vec.at(i);
    }
    return vec;
}

string shred(string& line, int idx){ // Shreds away the left or right side of a specific part of string and returns what was removed
    string shredded = line.substr(0,idx);
    line = line.substr(idx);
    return shredded;
}

bool notNum(string line){ // Checks to make sure a string input is not a number
    if (isblank(line.at(line.size()-1)))
        line.pop_back();
    for (size_t i = 0; i < line.size(); i++){
        if (!isdigit(line.at(i))){
            return true;
        }
    }
    return false;
}

int main() {
    string binaryID;
    vector<string> vec;
    vector<string> vecTrans;
    vec = readLines(); // Reads file and stores it's no-comment/no-space text into a vector
    for (auto line: vec) {
        string assembled = "";
        string shredded;
            if (line.size() != 16){
                    cout << "ERROR: instruction bit size not 16" << endl;
                    return 0;
            }
            if (line.at(0) == '0'){ // 0Binary ->  convert to @Decimal
                assembled += "@";
                string deci;
                deci = toDecimal(line);
                assembled += deci;
            } else { // Convert to Dest=Comp;JMP
                    //111acccccc -> CompID
                    //ddd -> DestID
                    //jjj -> JumpID
                    shredded = shred(line, 10);
                    string comp = shredded;
                    if (comp_OG.find(comp) != comp_OG.end()){
                        comp = comp_OG.at(comp);
                    } else {
                        cout << "ERROR: illegal HACK instruction" << endl;
                        return 0;
                    }
                    shredded = shred(line, 3);
                    string dest = shredded;
                    dest = dest_OG.at(dest);
                    string jump = jump_OG.at(line);
                    if (dest.size()){
                        assembled += dest+"=";
                    }
                    assembled += comp;
                    if (jump.size()){
                        assembled += ";"+jump;
                    }
            }
            vecTrans.push_back(assembled);
    }
    while (true) {
        if (vecTrans.empty()) {
            break;
        }
        cout << vecTrans.front() << endl;       
        vecTrans.erase(vecTrans.begin());
        // The job is finished, if so remove from queue
    }
    return 0;
}