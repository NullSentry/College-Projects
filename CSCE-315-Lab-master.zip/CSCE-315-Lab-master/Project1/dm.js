const body = document.querySelector('body');
const button = document.querySelector('#dbutton');
function toggleDark() {
  var style = document.getElementById("darkmode").href.split("/").at(-1);
  console.log(style);
  if (body.classList.contains('dark')) {
    body.classList.remove('dark');
    localStorage.setItem("theme", "light");
    //document.getElementById("batImg").src = "resources/BatB.png";
    document.getElementById("darkmode").href = "lightmode.css";
  } else {
    body.classList.add('dark');
    localStorage.setItem("theme", "dark");
    //document.getElementById("batImg").src = "resources/BatW.png";
    document.getElementById("darkmode").href = "darkmode.css";
  }
}

if (localStorage.getItem("theme") === "dark") {
  var style = document.getElementById("darkmode").href.split("/").at(-1);
  body.classList.add('dark');
  //document.getElementById("batImg").src = "resources/BatW.png";
  document.getElementById("darkmode").href = "darkmode.css";
}
document.querySelector('#dbutton').addEventListener('click', toggleDark);