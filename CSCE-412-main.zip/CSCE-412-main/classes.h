#ifndef CLASSES_H
#define CLASSES_H
#include <string>
#include <queue>
#include <unordered_set>
#include <ctype.h>
/** @file classes.h
@author Zachary K. Lewis
@version v1.0.0
@brief The header file.
@details This is the main headerfile of this program.
This file contains all of the class functions required for the loadbalancer program.
@date October 10th, 2022
*/
/// @brief Generates a random ip string.
/// @return A string (of a random ip).
std::string getRandIP();

/// @brief Generates a random integer.
/// @return An integer (1-10).
int getRandTime();

/// @brief Coinflips to determine true or false.
/// @return A boolean (50% true, 50% false)
bool newServer();
//! The Request Struct.
/*!
* This struct holds the Request IP (string), the webserver IP (string), and a time quantum (integer).
  The Request IP is the random IP of the Request itself. It is the starting IP address.
  The webserver IP is the destination IP address given to the Request by the webserver it is allotted to.
  The time quantum is the random amount of clock cycles required for the Request to finish.
*/
struct Request{
    std::string reqIP; //!< A random string of the Request IP. 
    std::string webIP; //!< A string of the webserver IP. 
    int timeQ; //!< An integer of the time quantum. 
};

//! The Webserver Class. 
/*!
* This class contains a single Request which it needs to process.
  A Request is given to the webserver by the Load Balancer.
  After the duration of the Request is completed, the webserver removes the Request and declares itself "free".
*/
class Webserver{
protected:
    std::string ip; //!< A random string of the webserver IP. 
    bool free; //!< A boolean of the webserver's "free" status. 
    Request req; //!< A Request object for the webserver to process. 
    int timeR; //!< An integer to count the time remaining for a Request. 
    int nDone; //!< An integer to keep track of the number of completed Requests. 
public: 
    /// @param ip An ip address string.
    Webserver(std::string ip); //!< A constructor function.
    /*!
      Takes in a ip address and generates an empty webserver with that IP.
    */
    /// @param req A Request object.
    void processReq(Request req); //!< The "main" function.
    /*!
      This function is called by the load balancer each clock cycle. Gives the webserver a new Request.
      Additionally, the function provides the Request with a destination IP, which is the webserver IP.
    */
    /// @returns A boolean (True = free, False = not free).
    bool isFree(); //!< A utility function.
    /*!
      This function is called by the load balancer every clock cycle to check if the processReq function can be called.
      Each time this function is called, the time remaining and number of completed Requests change acordingly.
      When a Request is finished, it it removed in this function and replaced with a placeholder Request.
      This function returns a boolean: True if free/False if not free.
    */
    /// @returns An integer (number of finished Requests).
    int get_nDone(); //!< A utility function.
    /*!
      This function is called by the load balancer when it runs its own get_nDone function. 
      This function returns the number of completed Requests as an integer. 
    */
    /// @returns An integer (time left for current Request).
    int get_ETA(); //!< A utility function.
    /*!
      This function calculates the amount of time remaining for a Request.
      This function returns the calculated time as an integer.
    */
    /// @return A string (the IP address of the webserver).
    std::string get_IP();  //!< A utility function.
    /*!
      This function returns the IP address of the webserver as a string.
    */
};

//! The Loadbalancer Class. 
/*!
  This class contains an array of web servers and a queue of Requests.
  The Request queue slowly dwindles as more Requests are sent to one of the web servers in the web server array.
  The algorithm used for the load balancer is a simple round robin algorithm.
*/
class Loadbalancer{
protected:
    int clockcycle; //** An integer of the current clockcycle. 
    std::queue<Request> reqQ; //!< A queue of Requests. 
    std::vector<Webserver> webV; //!< An array of web servers. 
public:
    /// @param reqQ A queue of Requests remaining.
    /// @param webV A vector array of Webservers to be managed by the load ballancer.
    Loadbalancer(std::queue<Request> reqQ, std::vector<Webserver> webV); //!< a constructor function.
    /*!
      This function takes in a queue of Requests and a vector of web servers.
      The function then generates a load balancer with those parameters.
    */
    /// @param req A Request to be added to the Loadbalancer queue.
    void pushQ(Request req); //!< A utility function.
    /*!
      This function adds new elements to the Request queue.
    */ 
    /// @return A Request (the current front of the queue).
    Request frontQ(); //!< A utility function.
    /*!
      This function grabs the Request at the front of the Request queue and returns it.
    */ 
    /// @return A Request (the Request popped from the queue).
    Request popQ(); //!< A utility function.
    /*!
      This function grabs the Request at the front of the Request queue and removes it from the queue.
      This function also returns the removed Request.
    */ 
    /// @return An integer (the number of cycles completed).
    int cycle(); //!< The "main" function.
    /*!
      This function is the main functionality of the class. Every cycle is 1 call to this function.
      This function runs the round robin algorithm and returns the current cycle count.
    */
    /// @return A boolean (True if the Request queue is empty, False otherwise).
    bool isEmpty(); //!< A utility function.
    /*!
      This function checks if the Request queue is empty and returns the boolean result.
    */
    /// @return An integer (the number of completed Requests of all Webservers).
    int get_nDone(); //!< A utility function.
    /*!
      This function checks and returns how many Requests completed as an integer.
    */
    /// @return An integer (the current size of the Request queue).
    int get_Size(); //!< A utility function.
    /*!
      This function checks and returns how many Requests remain in the Request queue.
    */
    
};

#endif  