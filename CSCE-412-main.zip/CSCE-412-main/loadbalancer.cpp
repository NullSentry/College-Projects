#include "classes.h"
#include <iostream>
#include <fstream>
/** @file loadbalancer.cpp
@author Zachary K. Lewis
@version v1.0.0
@brief The Loadbalancer class.
@details This file holds the functionality of the Loadbalancer class. 
All Loadbalancer functions are programed within this file.
@date October 10th, 2022
*/

Loadbalancer::Loadbalancer(std::queue<Request> reqQ, std::vector<Webserver> webV): reqQ(reqQ), webV(webV), clockcycle(0){}

void Loadbalancer::pushQ(Request req){
    this->reqQ.push(req);
}

Request Loadbalancer::popQ(){
    Request req;
    if (!this->reqQ.empty()){
        req = this->reqQ.front();
        this->reqQ.pop();
    }
    return req;
}

Request Loadbalancer::frontQ(){
    Request req;
    if (!this->reqQ.empty()){
        req = this->reqQ.front();
    }
    return req;
}

int Loadbalancer::cycle(){
    clockcycle++;
    for (int i = 0; i < webV.size(); i++){
        if (webV[i].isFree() && !isEmpty()){
            Request r = popQ();
            std::ofstream logger("logs.txt",std::ios_base::app);
            logger << "-----WEBSERVER FILLED-----" << std::endl;
            logger << "WEB IP"  << ", " << " REQ IP" << std::endl;
            logger << webV[i].get_IP() << ", " << r.reqIP << std::endl;
            logger << "--------------------------" << std::endl;
            logger.close();
            webV[i].processReq(r);
        }else if (isEmpty()){
            return clockcycle;
        }
    }
    return clockcycle; 
}

bool Loadbalancer::isEmpty(){
    return !(reqQ.size());
}
int Loadbalancer::get_Size(){
    return reqQ.size();
}
int Loadbalancer::get_nDone(){
    int total = 0;
    for (auto i : webV){
        total+= i.get_nDone();
    }
    return total;
}