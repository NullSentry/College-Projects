#include <iostream>
#include <fstream>
#include <climits>
#include "classes.h"
using namespace std;
/** @file main.cpp
@author Zachary K. Lewis
@version v1.0.0
@brief The main function of the loadbalancer program.
@details Sets up the creation and initalization of the Webserver vector, the Request queue, and the Loadbalancer.
After the user follows the user input instructions, this program will run the round robin algorithm.
@date October 10th, 2022
*/
/// @brief A hashmap to keep track of and prevent duplicate IPs.
std::unordered_set<std::string> uset;
std::string getRandIP(){
    std::string ip = std::to_string(rand() % 256 + 1) + "." 
    + std::to_string(rand() % 256 + 1) + "."
    + std::to_string(rand() % 256 + 1) + "."
    + std::to_string(rand() % 256 + 1);
    while(uset.find(ip) != uset.end()){
        ip = std::to_string(rand() % 256 + 1) + "." 
        + std::to_string(rand() % 256 + 1) + "."
        + std::to_string(rand() % 256 + 1) + "."
        + std::to_string(rand() % 256 + 1);
    }
    uset.insert(ip);
    return ip;
}
/// @brief A utility function to give a random time quantum
/// @param t1 The minimum of the range
/// @param t2 The maximum of the range
/// @return An integer (A value from t1 to t2).
int getRandTime(int t1 = 1, int t2 = 10){
    int time = (rand() % (t2-t1+1) + t1);
    return time;
}
/// @brief A utility function to give a coinflip of boolean values.
/// @return A boolean (True 50% of the time, False 50% of the time).
bool newServer(){
    int prob = (rand() % 2 + 1);
    if (prob == 1){
        return 1;
    }else{
        return 0;
    }
}
/// @brief The main function of the entire program.
/// @return An integer (finishes the program).
int main()
{
    std::queue<Request> reqQ;
    vector<Webserver> webV;
    int t1 = 1;
    int t2 = 10;
    int minT = INT_MAX;
    int maxT = INT_MIN;
    int num = 0;
    int n = 0;
    int maxNum;
    char yn = 'Y';
    int total = 0;
    int start = 0;
    std::ofstream logger;
    logger.open("logs.txt", std::ofstream::out | std::ofstream::trunc);
    logger << "Cycle #: " << 1 << std::endl;
    
    std::cout<<"Enter the total number of servers"<<std::endl;
    cin >> n;
    std::cout<<"Enter the maximum amount of allotted time to handle the Requests"<<std::endl;
    cin >> maxNum;
    std::cout<<"Enter the minimum time quantum allowed for a request"<<std::endl;
    cin >> t1;
    std::cout<<"Enter the maximum time quantum allowed for a request"<<std::endl;
    cin >> t2;
    std::cout<<"Stop when queue is empty (Y/N)"<<std::endl;
    cin >> yn;
    for (int i = 0; i < 2*n; i++){
        Request r = {getRandIP(), "x.x.x.x", getRandTime(t1,t2)};
        logger << "---NEW REQUEST GENERATED---" << std::endl;
        logger << " REQ IP, REQ Duration" << std::endl;
        logger << r.reqIP <<", " << r.timeQ << std::endl;
        logger << "--------------------------" << std::endl;
        if (r.timeQ > maxT)
            maxT = r.timeQ;
        if (r.timeQ < minT)
            minT = r.timeQ;
        reqQ.push(r);
    }
    for (int i = 0; i < n; i++){
       webV.push_back((getRandIP()));
    }
    Loadbalancer x = Loadbalancer(reqQ, webV);
    start = x.get_Size();
    logger.close();
    while ((!x.isEmpty() or toupper(yn)=='N') and (num < maxNum)){
        std::ofstream logger("logs.txt",std::ios_base::app);
        if (newServer()){
            Request r = {getRandIP(), "x.x.x.x", getRandTime(t1,t2)};
            if (r.timeQ > maxT)
                maxT = r.timeQ;
            if (r.timeQ < minT)
                minT = r.timeQ;
            logger << "---NEW REQUEST GENERATED---" << std::endl;
            logger << " REQ IP, REQ Duration" << std::endl;
            logger << r.reqIP <<", " << r.timeQ << std::endl;
            logger << "--------------------------" << std::endl;
            x.pushQ(r);
        }
        num = x.cycle();
        logger << "Cycle #: " << num << std::endl;
        logger.close();
    }
    total = x.get_nDone();
    std::ofstream logger2("logs.txt",std::ios_base::app);
    logger2<<"Final Number of Cycles: "<<num<<std::endl;
    logger2<<"Final Number of Completed Requests: "<<total<<std::endl;
    logger2<<"Starting Queue Size: "<<start<<std::endl;
    logger2<<"Final Queue Size: "<<x.get_Size()<<std::endl;
    logger2<<"Minimum Task Time: "<<minT<<std::endl;
    logger2<<"Maximum Task Time: "<<maxT<<std::endl;
    logger2<<"Minimum Allowed Task Time: "<<t1<<std::endl;
    logger2<<"Maximum Allowed Task Time: "<<t2<<std::endl;
    logger2.close();
    std::cout <<"Finished."<< std::endl;
    return 0;
}