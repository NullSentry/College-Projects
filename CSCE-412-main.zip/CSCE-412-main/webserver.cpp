#include "classes.h"
#include <iostream>
#include <fstream>
/** @file webserver.cpp
@author Zachary K. Lewis
@version v1.0.0
@brief The Webserver class.
@details This file holds the functionality of the Webserver class. 
All Webserver functions are programed within this file.
@date October 10th, 2022
*/

Webserver::Webserver(std::string ip): req({ "x.x.x.x", "x.x.x.x", 0 }), free(1), timeR(0), nDone(0), ip(ip){}

void Webserver::processReq(Request req){
    this->req = req;
    this->req.webIP=ip;
}

bool Webserver::isFree(){
    if (this->req.reqIP != "x.x.x.x"){
        if (this->req.timeQ <= timeR+1){
            this->timeR = 0;
            this->nDone++;
            std::ofstream logger("logs.txt",std::ios_base::app);
            logger << "-----WEBSERVER EMPTIED-----" << std::endl;
            logger << "WEB IP" << ", " << "Duration" << std::endl;
            logger << req.webIP << ", " << req.timeQ << std::endl;
            logger << "--------------------------" << std::endl;
            logger.close();
            this->req = { "x.x.x.x", "x.x.x.x", 0 };
            return 1;
        } else {
            this->timeR++;
            return 0;
        }
    }else{
        return 1;
    }
}

int Webserver::get_nDone(){
    return this->nDone;
}

int Webserver::get_ETA(){
    return (this->req.timeQ)-(this->timeR);
}

std::string Webserver::get_IP(){
    return ip;
}
